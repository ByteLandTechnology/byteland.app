import React from 'react';
import {AbsoluteFill,Audio,useCurrentFrame,staticFile} from 'remotion';
import {BrandCanvas} from './BrandCanvas';
import timing from './timing.json';
export const durationInFrames=timing.durationInFrames;
const blue='#007aff',green='#258b40',red='#d82b22',ink='#172033',muted='#5c687b';
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const ease=(x:number)=>{const u=clamp(x);return u*u*u*(u*(u*6-15)+10)};
const mix=(a:number,b:number,u:number)=>a+(b-a)*u;
const colorMix=(a:string,b:string,u:number)=>'#'+[1,3,5].map(i=>Math.round(mix(parseInt(a.slice(i,i+2),16),parseInt(b.slice(i,i+2),16),u)).toString(16).padStart(2,'0')).join('');
type Panel={x:number;y:number;w:number;h:number;color:string;alpha:number};
type Copy={text:string;x:number;y:number;size:number;color?:string;weight?:number;anchor?:'start'|'middle'|'end';panel?:number;shared?:string};
type Scene={header:string;panels:Panel[];copy:Copy[]};
const panel=(x:number,y:number,w:number,h:number,color=blue,alpha=1):Panel=>({x,y,w,h,color,alpha});
const text=(text:string,x:number,y:number,size=27,color=muted,weight=400,p?:number,shared?:string):Copy=>({text,x,y,size,color,weight,panel:p,shared});
const cardCopy=(p:Panel,title:string,lines:string[],i:number):Copy[]=>[text(title,p.x+30,p.y+54,32,p.color,700,i),...lines.map((s,j)=>text(s,p.x+30,p.y+105+j*41,27,muted,400,i))];
const P:Panel[][]=[
 [panel(80,526,690,0,blue),panel(825,526,695,0,green),panel(80,660,1440,0,blue,0)],
 [panel(80,218,690,300,blue),panel(825,218,695,300,green),panel(80,660,1440,0,blue,0)],
 [panel(80,220,690,286,blue),panel(830,220,690,286,green),panel(80,660,1440,0,blue,0)],
 [panel(80,218,645,277,blue),panel(780,218,740,277,red),panel(80,622,1440,0,blue,.7)],
 [panel(80,255,690,300,blue),panel(825,255,695,300,green),panel(80,660,1440,0,red,.7)],
 [panel(80,300,445,270,green),panel(577,300,445,270,blue),panel(1074,300,446,270,red)],
];
const scenes:Scene[]=[
 {header:'THE LAUNCH',panels:P[0],copy:[
 text('OCTOBER 12, 2026',80,238,30,blue,700),text('Muse Wonder',76,359,100,ink,700,undefined,'model-name'),
 text('Long-running agents. Read the evidence.',80,430,39),
 text('Active Memory',80,579,34,blue,700,0),text('Active Focus',825,579,34,green,700,1),text('Meta’s capability names',80,637,26)]},
 {header:'WHICH MODEL?',panels:P[1],copy:[
 text('Muse Wonder',110,272,32,blue,700,0,'model-name'),...['Model API preview · Standard mode','muse-wonder-1.0','Also available in Muse Code','1M-token context window'].map((s,j)=>text(s,110,323+j*41,27,muted,400,0)),
 ...cardCopy(P[1][1],'Muse Wonder Full',['Eligible Muse Code subscriptions','Separate, higher-capability variant','Not available through Model API'],1),
 text('reasoning effort = max',80,590,31,ink,700),text('≠',500,590,33,red),text('Muse Wonder Full',560,590,31)]},
 {header:'MEMORY',panels:P[2],copy:[
 text('Recall from supplied context',110,274,32,blue,700,0),text('MemoryBench',110,325,27,blue,700,0,'memory-bench'),text(': 64K–100K tokens',329,325,27,muted,400,0),
 text('Facts, distractions and updates',110,366,27,muted,400,0),text('Internal evaluation',110,407,27,muted,400,0),
 ...cardCopy(P[2][1],'Durable application memory',['Storage across sessions','Retrieval after a restart','Not established by a recall score'],1),
 {...text('Context recall ≠ storage guarantee',800,595,36,ink,700),anchor:'middle'}]},
 {header:'READ THE METHODS',panels:P[3],copy:[
 text('MemoryBench',110,272,32,blue,700,0,'memory-bench'),text(' + FocusBench',370,272,32,blue,700,0),
 ...['Internal benchmarks','Read the setup and grading','Scores reflect those conditions'].map((s,j)=>text(s,110,323+j*41,27,muted,400,0)),
 ...cardCopy(P[3][1],'SWE-Marathon',['Different agent products / harnesses','Not a controlled','common-harness comparison'],1),
 text('Model + harness conditions shape the reported result.',80,578,31)]},
 {header:'INDEPENDENT EVIDENCE',panels:P[4],copy:[
 text('Artificial Analysis · Intelligence Index v4.3.2',80,184,31,ink,700),text('Snapshot checked October 14, 2026',80,226,25),
 text('Muse Wonder',110,309,32,blue,700,0),text('52',110,444,116,blue,700,0),text('Maximum reasoning effort',110,503,27,muted,400,0),
 text('Muse Wonder Full',855,309,32,green,700,1),text('56',855,444,116,green,700,1),text('Maximum reasoning effort',855,503,27,muted,400,1),
 text('Composite score ≠ repository reliability',80,621,34,ink,700)]},
 {header:'CHOOSING A SYSTEM',panels:P[5],copy:[
 text('Model + tools + permissions + runtime',80,218,36,ink,700),
 ...cardCopy(P[5][0],'Outcomes',['Verified final state','Fit to your workload','Compare like for like'],0),
 ...cardCopy(P[5][1],'Elapsed time',['End-to-end duration','Include recovery time','Keep the event log'],1),
 ...cardCopy(P[5][2],'Total cost',['Tokens + tool charges','Record the settings','Compare equal budgets'],2),
 text('Compare on your actual workload.',80,638,31)]},
];
export const transitionBefore=.35,transitionAfter=.85;
function stateAt(t:number){
 for(let i=1;i<timing.scenes.length;i++){
  const boundary=timing.scenes[i];if(t>=boundary-transitionBefore&&t<boundary+transitionAfter)return {from:i-1,to:i,u:(t-boundary+transitionBefore)/(transitionBefore+transitionAfter),boundary};
 }
 let index=0;for(let i=1;i<timing.scenes.length;i++)if(t>=timing.scenes[i])index=i;
 return {from:index,to:index,u:1,boundary:0};
}
const Text=({item,opacity=1,dx=0,dy=0}:{item:Copy;opacity?:number;dx?:number;dy?:number})=><text x={item.x+dx} y={item.y+dy} fontSize={item.size} fill={item.color||muted} fontWeight={item.weight||400} textAnchor={item.anchor||'start'} opacity={opacity}>{item.text}</text>;
export function Frame({frame}:{frame:number}){
 const t=frame/60,transition=stateAt(t),{from,to,u}=transition,moving=from!==to,q=ease(u),a=scenes[from],b=scenes[to];
 const morph=a.panels.map((p,i)=>{const v=b.panels[i];return {x:mix(p.x,v.x,q),y:mix(p.y,v.y,q),w:mix(p.w,v.w,q),h:mix(p.h,v.h,q),color:colorMix(p.color,v.color,q),alpha:mix(p.alpha,v.alpha,q)}});
 // The methods/evidence baseline folds right first, then opens into the cost card.
 // This keeps the three destination panels separate while their geometry is shared.
 if(moving&&to===5){const fold=ease(u/.45),grow=ease((u-.45)/.55);morph[2]={...morph[2],x:mix(a.panels[2].x,b.panels[2].x,fold),w:mix(a.panels[2].w,b.panels[2].w,fold),y:mix(a.panels[2].y,b.panels[2].y,grow),h:mix(a.panels[2].h,b.panels[2].h,grow)};}
 // A brief text overlap sits inside the moving panel; unrelated words never morph.
 // At the index-to-selection boundary, all score numerals leave before the new copy enters.
 const oldOpacity=moving?1-ease((u-.32)/(to===5?.18:.26)):0;
 const newOpacity=moving?ease((u-(to===5?.62:.51))/(to===5?.25:.28)):1;
 const common=new Set(a.copy.filter(x=>x.shared&&b.copy.some(y=>y.shared===x.shared&&y.text===x.text)).map(x=>x.shared!));
 const headerIn=ease((t-3.60)/.5),bodyIn=ease((t-3.68)/.6),out=ease((t-(timing.outro-.16))/.46),headerOut=ease((t-(timing.outro-.16))/.16);
 const drawCopy=(scene:Scene,alpha:number,isOld=false)=>scene.copy.filter(item=>!common.has(item.shared||'')).map((item,i)=>{
  const p=item.panel;let dx=p===undefined?0:morph[p].x-scene.panels[p].x,dy=p===undefined?0:morph[p].y-scene.panels[p].y;let opacity=alpha,copy=item;
  if(moving&&from===2&&to===3&&isOld&&item.text==='Recall from supplied context')opacity=Math.min(opacity,1-ease((u-.20)/.22));
  if(moving&&from===0&&isOld&&p!==undefined)opacity=Math.min(opacity,1-ease((u-.15)/.25));
  if(moving&&to===5&&!isOld&&p===2)opacity*=ease((u-.82)/.18);
  // Continuations stay attached to the true width/baseline of the shared word.
  if(common.has('memory-bench')&&(item.text===': 64K–100K tokens'||item.text===' + FocusBench')){
   const first=a.copy.find(x=>x.shared==='memory-bench')!,last=b.copy.find(x=>x.shared==='memory-bench')!,size=mix(first.size,last.size,q);
   copy={...item,x:mix(first.x,last.x,q)+256.140625*size/32+(item.text===' + FocusBench'?12:0),y:mix(first.y,last.y,q),size};dx=0;dy=0;
  }
  return <Text key={i} item={copy} opacity={opacity} dx={dx} dy={dy}/>;
 });
 return <svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900" role="img" aria-label={`Muse Wonder: ${b.header}`}>
 <defs><linearGradient id="theme"><stop offset="0%" stopColor="#0062cc"/><stop offset="50%" stopColor="#208235"/><stop offset="100%" stopColor="#d92820"/></linearGradient>
 <clipPath id="headerClip"><rect x="140" y="32" width={1364*headerIn*(1-headerOut)} height="82"/></clipPath><clipPath id="bodyClip"><rect x="76" y="135" width={1448*bodyIn*(1-out)} height="665"/></clipPath>
 <linearGradient id="progress"><stop offset="0%" stopColor="#007aff"/><stop offset="50%" stopColor="#34c759"/><stop offset="100%" stopColor="#ff3b30"/></linearGradient><clipPath id="progressClip"><rect x="0" y="892.5" width={1600*clamp(frame/(timing.durationInFrames-1))} height="7.5"/></clipPath></defs>
 <g fontFamily="DejaVu Sans, sans-serif">
 <g clipPath="url(#headerClip)" transform={`translate(${48*(1-headerIn)-24*headerOut} 0)`}>
 {moving&&<text x={140-20*ease(u)} y="91" fontSize="36" fontWeight="700" fill="url(#theme)" opacity={1-ease((u-.28)/.20)}>{a.header}</text>}
 <text x={140+(moving?20*(1-ease((u-.5)/.5)):0)} y="91" fontSize="36" fontWeight="700" fill="url(#theme)" opacity={moving?ease((u-.5)/.2):1}>{b.header}</text>
 </g>
 <g clipPath="url(#bodyClip)" transform={`translate(${64*(1-bodyIn)-48*out} ${-12*out})`}>
 {morph.map((p,i)=><g key={i} data-shared-panel={i} opacity={p.alpha}><rect x={p.x} y={p.y} width={p.w} height={Math.max(p.h,.01)} rx={Math.min(24,p.h/2)} fill="white" stroke="#dce4ef" strokeWidth="2"/>{p.h>48&&<rect x={p.x} y={p.y+24} width="5" height={p.h-48} rx="2.5" fill={p.color}/>}</g>)}
 {moving&&drawCopy(a,oldOpacity,true)}{drawCopy(b,newOpacity)}
 {[...common].map(id=>{const s=a.copy.find(x=>x.shared===id)!,v=b.copy.find(x=>x.shared===id)!;return <Text key={id} item={{...s,x:mix(s.x,v.x,q),y:mix(s.y,v.y,q),size:mix(s.size,v.size,q),weight:Math.round(mix(s.weight||400,v.weight||400,q)),color:colorMix(s.color||muted,v.color||muted,q)}}/>})}
 </g></g>
 <rect x="0" y="892.5" width="1600" height="7.5" fill="#e2e8f0"/><rect x="0" y="892.5" width="1600" height="7.5" fill="url(#progress)" clipPath="url(#progressClip)"/>
 </svg>;
}
export const Video=()=>{const frame=useCurrentFrame();return <AbsoluteFill style={{background:'#f7f9fc'}}><BrandCanvas time={frame/60}/><div style={{position:'absolute',width:1600,height:900,transform:'scale(.8)',transformOrigin:'top left'}}><Frame frame={frame}/></div><Audio src={staticFile('review-audio.wav')}/></AbsoluteFill>};
