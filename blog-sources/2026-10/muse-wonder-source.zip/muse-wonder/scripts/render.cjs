// Browser Remotion route. This was NOT used for the delivered movie because
// this execution environment denies Chromium process-singleton socket creation.
// No Chromium launch flags are added to work around that denial.
const path=require('path');
const {bundle}=require('@remotion/bundler');
const {renderMedia,selectComposition}=require('@remotion/renderer');
(async()=>{
 const root=path.resolve(__dirname,'..');
 const serveUrl=await bundle({entryPoint:path.join(root,'src/index.tsx'),publicDir:path.join(root,'public')});
 const browserExecutable='/usr/bin/chromium';
 const composition=await selectComposition({serveUrl,id:'MuseWonderReview',browserExecutable});
 await renderMedia({serveUrl,composition,codec:'h264',outputLocation:path.resolve(root,'../deliverables/video/muse-wonder-remotion.mp4'),browserExecutable,concurrency:2,crf:18,pixelFormat:'yuv420p'});
})().catch(e=>{console.error(e);process.exitCode=1});
