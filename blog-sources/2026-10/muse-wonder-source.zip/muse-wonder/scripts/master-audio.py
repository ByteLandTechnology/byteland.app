"""Two-pass objective loudness mastering. No playback/listening claim."""
from pathlib import Path
import json,re,subprocess
P=Path(__file__).resolve().parents[1];source=P/'public/review-audio.wav'
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True)
first=run(['ffmpeg','-hide_banner','-i',str(source),'-af','loudnorm=I=-18:TP=-1.5:LRA=8:print_format=json','-f','null','-'])
measurement=json.JSONDecoder().raw_decode(first.stderr[first.stderr.rfind('{'):])[0]
f=('loudnorm=I=-18:TP=-1.5:LRA=8:'
 f"measured_I={measurement['input_i']}:measured_TP={measurement['input_tp']}:"
 f"measured_LRA={measurement['input_lra']}:measured_thresh={measurement['input_thresh']}:"
 f"offset={measurement['target_offset']}:linear=true:print_format=json")
target=P/'out/master-audio.wav';target.parent.mkdir(exist_ok=True)
second=run(['ffmpeg','-hide_banner','-y','-i',str(source),'-af',f,'-ar','24000','-ac','1','-c:a','pcm_s16le',str(target)])
result=json.JSONDecoder().raw_decode(second.stderr[second.stderr.rfind('{'):])[0];source.write_bytes(target.read_bytes())
(P/'qa/audio-mastering.json').write_text(json.dumps({'targetIntegratedLUFS':-18,'targetTruePeakDBTP':-1.5,'measurement':measurement,'result':result,'listeningPerformed':False},indent=2)+'\n')
print(json.dumps(result,indent=2))
