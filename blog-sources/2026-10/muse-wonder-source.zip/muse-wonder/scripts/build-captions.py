"""Build external VTT tracks from measured sentence-clip timings. No network."""
from pathlib import Path
import json,textwrap,unicodedata
P=Path(__file__).resolve().parents[1]
translations=json.loads((P/'captions/translations.json').read_text())
timing=json.loads((P/'audio/narration-timing.json').read_text())
assert len(timing['segments'])==6, 'Wait for all six narration segments'
entries=[]
for s in timing['segments']:
 lines=translations[s['id']]
 assert len(lines)==len(s['sentences']), f"Sentence mismatch: {s['id']}"
 for i,(sentence,trans) in enumerate(zip(s['sentences'],lines)):
  entries.append({'start':sentence['start'],'end':sentence['end'],'translation':trans,'segment':s['id'],'sentenceIndex':i+1})

def ts(t):
 msec=round(t*1000);h,msec=divmod(msec,3600000);m,msec=divmod(msec,60000);s,msec=divmod(msec,1000)
 return f'{h:02}:{m:02}:{s:02}.{msec:03}'
def wrap(s,lang):
 if lang=='en':return '\n'.join(textwrap.wrap(s,54,break_long_words=False,break_on_hyphens=False))
 # Break long CJK text at modest display widths; never split model identifiers.
 if len(s)<=38:return s
 parts=s.split(' ')
 if len(parts)>1:
  return '\n'.join(textwrap.wrap(s,38,break_long_words=True,break_on_hyphens=False))
 middle=len(s)//2;cut=min(range(max(1,middle-8),min(len(s),middle+9)),key=lambda i:abs(i-middle)-(3 if s[i-1] in '，、。；' else 0))
 return s[:cut]+'\n'+s[cut:]

out=P.parent/'deliverables/video';out.mkdir(parents=True,exist_ok=True)
report={'cue_count_per_track':len(entries),'timing_basis':'Measured full-timeline start/end of synthesized sentence clips, with up to 80 ms caption tail; no ASR or human listening alignment claimed.','languages':['en','zh-Hans','zh-Hant','ja'],'cues':[]}
for lang in report['languages']:
 chunks=['WEBVTT','']
 for i,e in enumerate(entries):
  end=min(e['end']+.08,entries[i+1]['start']-.03 if i+1<len(entries) else 61.3)
  assert 0<=e['start']<end<=64.466667
  chunks.extend([str(i+1),f"{ts(e['start'])} --> {ts(end)}",wrap(e['translation'][lang],lang),''])
 content='\n'.join(chunks)+'\n'
 for folder in [P/'captions',out]:(folder/f'captions.{lang}.vtt').write_text(content,encoding='utf-8')
for i,e in enumerate(entries):report['cues'].append({k:e[k] for k in ['start','end','segment','sentenceIndex']})
(P/'qa/caption-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(f"Built {len(entries)} precisely scheduled sentence cues in each of four VTT files.")
