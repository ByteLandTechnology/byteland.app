# Muse Wonder narration provenance, revision v3

Generated locally on 2026-10-14 from the supplied v3 script. This is synthetic narration using a packaged stock voice. No personal voice reference, impersonation, paid inference, credentials, API services, browser access, new package installation, or model downloads were used for this revision.

## Stock voice and existing local runtime

- Voice: Kokoro `af_heart`, American English stock voice.
- Model: Kokoro v1.0 fp16 ONNX export, using the previously installed local model and voice bank.
- Runtime: onnxruntime 1.22.1 CPUExecutionProvider. Telemetry disabled through the runtime API and environment setting.
- Python wrapper: kokoro-onnx 0.6.1 (MIT); Python 3.12.14.
- Phonemizer 3.4.0 and eSpeak-NG perform grapheme-to-phoneme conversion; Kokoro produces the neural audio. The GPL licensing of these software components is separate from the model. No engine/model binaries are included in the narration deliverables.
- The original generator and installed Kokoro inference, tokenizer, session, chunking, pause, timing, and trim implementation were inspected before execution.

Previously recorded publisher sources, reused without redownloading:

- Original model and voice: https://huggingface.co/hexgrad/Kokoro-82M
- Stock voice documentation: https://huggingface.co/hexgrad/Kokoro-82M/blob/main/VOICES.md
- ONNX export and voice bank: https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.1
- Wrapper: https://pypi.org/project/kokoro-onnx/0.6.1/

The original model card's Apache-2.0 and training-data statements are publisher statements, not an independent training-data audit. Previously recorded package provenance is retained in `tts/verified-package-manifest.json` and the original `tts/NARRATION-PROVENANCE.md`.

## Verified local hashes

- Model: f3a290d384fbb27966d462905c71a46cef9e5fd00516b40df32a0b4afe77ac96
- Voice bank: bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d
- Exact v3 script JSON: d2c17cb41a5f9df86f66bbf1258cf56cc1d49723ca5b7700049f24a9e45b1747
- V3 generator: d8e789c2c3c252a0190639430c72cf4688b4b450b86257664975a7aaf878987d
- V3 narration WAV: f59d5a6c393cbc322e02bd8415c168c4ca86c42bdead3546938bef7020ca2ca2

The local model and voice-bank hashes were rechecked against the previously recorded publisher hashes. No change was made to the v3 script text.

## Synthesis and timing

Each sentence was generated independently. Pronunciation-only normalization speaks `API` as A P I, `SWE Marathon` as S W E Marathon, `MemoryBench` as Memory Bench, and the hyphenated API identifier as Muse Wonder one point zero. Displayed wording and meaning are unchanged.

Rate adjustment uses the neural model's speed input. No post-generation time stretching or pitch shifting is used. The segment speeds are 1.082823–1.263176. Inter-sentence gaps are 0.18 seconds, with 4 ms edge fades. One uniform gain of 4.626532 dB is applied to both the complete narration stem and individual sentence/segment clips.

- launch: neural speed 1.166642; measured 4.150000–11.614625 seconds; window ends 11.75.
- availability: neural speed 1.254547; measured 12.100000–21.621958 seconds; window ends 21.75.
- memory: neural speed 1.082823; measured 22.100000–32.561333 seconds; window ends 32.70.
- benchmarks: neural speed 1.168620; measured 33.100000–42.589250 seconds; window ends 42.70.
- independent: neural speed 1.263176; measured 43.100000–53.434667 seconds; window ends 53.65.
- selection: neural speed 1.248616; measured 54.100000–61.007292 seconds; window ends 61.15.

Sentence start/end metadata is measured from exact rendered sample counts on the complete timeline, including any edge silence retained by the model. This model provides phoneme timing output: true. No word-level alignment or speech-recognition transcript is claimed.

The track is generated directly as exactly 1,547,200 samples, or 3868/60 seconds (64.4666666667 seconds), at 24 kHz, mono, signed 16-bit PCM WAV. The intro, outro, and spaces outside sentence clips are silent. No effects or music are mixed into this stem.

## Objective validation

- All six segments and all 14 sentence clips fit their assigned editorial windows.
- Sentence and segment PCM audio matches the corresponding complete-timeline samples exactly.
- FFmpeg successfully decoded the narration WAV to the same PCM bytes.
- No clipped integer samples; finite samples throughout.
- Sample peak: -2.000183 dBFS.
- True peak: -1.9 dBTP.
- RMS: -21.221924 dBFS.
- Integrated loudness: -21.7 LUFS; loudness range: 2.8 LU. Measured with FFmpeg EBU R128 in mono with true-peak analysis; no validation-time loudness processing applied.

These are technical audio checks. No auditory listening review, perceptual quality approval, independent speech-recognition check, or factual model-testing claim is made.

## Reproduction and files

Run `tts/venv/bin/python tts/generate_narration_v3.py`, then `tts/venv/bin/python tts/validate_narration_v3.py`, then `tts/venv/bin/python tts/finalize_narration_v3.py` from the project root. All required model/runtime inputs are already local; the scripts do not download or call services.

Sentence and segment clips, timing reports, decode metadata, generation log, and loudness evidence are retained under `tts/output-v3` and `tts/generation-v3.log`. Delivery copies of narration, timing, validation, provenance, and hashes are in `video-muse/audio`.
