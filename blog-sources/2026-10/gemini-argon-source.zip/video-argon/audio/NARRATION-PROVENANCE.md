# Gemini 4 Argon narration provenance

Generated locally on 14 October 2026 with Kokoro v1.0 fp16, kokoro-onnx 0.6.1 and onnxruntime 1.22.1 CPUExecutionProvider. Voice: `af_heart`, a stock American-English voice. No personal voice reference, impersonation, paid inference, API call, credentials, new installation or model download was used. Runtime telemetry was disabled.

The previously installed offline model and voice bank were read without modification. Inputs were rehashed:

- Model SHA-256: f3a290d384fbb27966d462905c71a46cef9e5fd00516b40df32a0b4afe77ac96
- Voice-bank SHA-256: bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d
- Script SHA-256: e2941fe35715719c9e89d36327a8781d8b998c587f6bd4bce2e341f4173af92d
- Generator SHA-256: 0328f25d7fbfb809691eb3e11004dcb3d9c844a8c206ac4822f78c0b830c07a7
- Narration WAV SHA-256: 10346030c45306f93daf6717b1d35480961ecf7e79a063f3039c71d15c1fc9ea

Publisher documentation, model/voice licenses and package manifest are preserved in `narration-licenses/`. Publisher origins: https://huggingface.co/hexgrad/Kokoro-82M and https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.1 . The model publisher's Apache-2.0 and training-data declarations are not an independent training-data audit. Engine and model binaries are excluded from the deliverable.

The full stem contains 1787200 mono samples at 24 kHz, exactly 4468/60 seconds. Each sentence was synthesized independently; its timeline placement is measured by sample count, with 0.18-second gaps. Rate fitting uses the model's speed input, without post-generation time stretching. A uniform gain of 4.054596 dB is applied. Four-millisecond edge fades limit clip-boundary clicks. Intro/outro are silent in the narration stem; effects are mixed separately.

Pronunciation normalization: Gemini 4 → Gemini four; API → A P I; PDFs → P D Fs. These change pronunciation only. No auditory pronunciation, perceptual-quality or independent ASR validation is claimed.

Segment generation:
- launch: speed 1.000000, measured 4.150000–13.182000 s.
- capabilities: speed 0.942929, measured 14.100000–25.323958 s.
- case: speed 0.850000, measured 26.100000–36.626667 s.
- evaluations: speed 0.873250, measured 38.100000–49.169333 s.
- reactions: speed 0.904668, measured 50.100000–60.316000 s.
- takeaway: speed 0.896350, measured 61.100000–70.825333 s.

Technical validation and final mixed-audio loudness are in `narration-validation.json` and `../qa/validation.json`. The final mix ducks original synthesized effects under speech and targets -18 LUFS with -1.5 dBTP two-pass mastering.
