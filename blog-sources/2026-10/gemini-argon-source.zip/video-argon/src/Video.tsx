import React from 'react';
import {AbsoluteFill,Audio,useCurrentFrame,staticFile} from 'remotion';
import {BrandCanvas} from './BrandCanvas';
import timing from './timing.json';
export const durationInFrames=timing.durationInFrames;
const blue='#006bdc',green='#258b40',red='#ce3027',ink='#172033',muted='#5c687b';
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const ease=(x:number)=>{const u=clamp(x);return u*u*u*(u*(u*6-15)+10)};
const mix=(a:number,b:number,u:number)=>a+(b-a)*u;
const colorMix=(a:string,b:string,u:number)=>'#'+[1,3,5].map(i=>Math.round(mix(parseInt(a.slice(i,i+2),16),parseInt(b.slice(i,i+2),16),u)).toString(16).padStart(2,'0')).join('');
type Panel={x:number;y:number;w:number;h:number;color:string;alpha:number};
type Copy={text:string;x:number;y:number;size:number;color?:string;weight?:number;anchor?:'start'|'middle'|'end';panel?:number;shared?:string};
type Scene={header:string;panels:Panel[];copy:Copy[]};
const panel=(x:number,y:number,w:number,h:number,color=blue,alpha=1):Panel=>({x,y,w,h,color,alpha});
const text=(text:string,x:number,y:number,size=27,color=muted,weight=400,p?:number,shared?:string):Copy=>({text,x,y,size,color,weight,panel:p,shared});
const cardCopy=(p:Panel,title:string,lines:string[],i:number):Copy[]=>[text(title,p.x+30,p.y+57,32,p.color,700,i),...lines.map((s,j)=>text(s,p.x+30,p.y+115+j*43,27,muted,400,i))];
const P:Panel[][]=[
 [panel(80,531,675,0,blue),panel(835,531,685,0,green),panel(80,668,1440,0,red,0)],
 [panel(80,258,800,350,blue),panel(980,258,540,350,green),panel(80,695,1440,0,red,0)],
 [panel(80,246,690,336,blue),panel(830,246,690,336,green),panel(80,668,1440,0,red,0)],
 [panel(80,262,690,330,green),panel(830,262,690,330,blue),panel(80,668,1440,0,red,.6)],
 [panel(80,256,690,344,green),panel(830,256,690,344,red),panel(80,668,1440,0,red,.6)],
 [panel(80,305,445,276,green),panel(577,305,445,276,blue),panel(1074,305,446,276,red)],
];
const scenes:Scene[]=[
 {header:'THE RELEASE',panels:P[0],copy:[
 text('Gemini 4 Argon',76,301,90,ink,700,undefined,'model-name'),
 text('Tougher coding. Longer tasks.',80,376,41),
 text('Google’s pitch',80,429,27),
 text('SEPTEMBER 30',80,582,31,blue,700,0),text('Unveiled',80,625,27,muted,400,0),
 text('OCTOBER 13',835,582,31,green,700,1),text('Wider paid rollout',835,625,27,muted,400,1)]},
 {header:'WHAT YOU GET',panels:P[1],copy:[
 text('Gemini 4 Argon',80,192,36,ink,700,undefined,'model-name'),text('gemini-4-argon',80,234,26,muted),
 ...cardCopy(P[1][0],'Many inputs',['Text · Images · Video','Audio · PDFs'],0),
 ...cardCopy(P[1][1],'Text output',['No image generation','No audio generation'],1),
 text('1,048,576 shared tokens',110,508,32,blue,700,0),text('Input + thinking + output',110,550,27,muted,400,0),
 text('Google Gemini API documentation',80,666,25)]},
 {header:'PROMISE AND REVIEW',panels:P[2],copy:[
 text('Google’s 11-hour coding case',80,195,36,ink,700),
 text('6 proposals',110,303,39,blue,700,0),text('Generated in the vendor case study',110,525,26,muted,400,0),
 text('2 shipped',860,303,39,green,700,1),text('After human review',860,525,28,muted,400,1),
 text('Promising output still needs careful checks.',80,652,33,ink,700)]},
 {header:'RANKINGS DEPEND ON THE TEST',panels:P[3],copy:[
 text('Independent evaluations · Checked October 14',80,200,30,ink,700),
 ...cardCopy(P[3][0],'Vals Index',['Sector-weighted tasks'],0),text('#1',110,474,102,green,700,0),text('Index v2.1',110,544,27,muted,400,0),
 ...cardCopy(P[3][1],'Artificial Analysis',['Intelligence Index'],1),text('#8',860,474,102,blue,700,1),text('Argon at high effort',860,544,27,muted,400,1),
 text('Different suites. Different answers.',80,652,33,ink,700)]},
 {header:'EARLY USER REACTIONS',panels:P[4],copy:[
 text('Two Reddit reports · October 13',80,200,30,ink,700),
 ...cardCopy(P[4][0],'Praise',['Speed','Security analysis','r/GeminiAI'],0),
 ...cardCopy(P[4][1],'Caution',['Architecture mistakes','Needed corrective pointers','r/google_antigravity'],1),
 text('Anecdotes with limited scope, not controlled tests.',80,652,31,ink,700)]},
 {header:'OUR TAKEAWAY',panels:P[5],copy:[
 text('Try a task with a clear finish line.',80,220,41,ink,700),
 ...cardCopy(P[5][0],'Useful results',['Verify the outcome','Check important claims'],0),
 ...cardCopy(P[5][1],'Elapsed time',['Include review','Include corrections'],1),
 ...cardCopy(P[5][2],'Total cost',['Tokens + tools','Watch thinking effort'],2),
 text('Promising for hard work. Keep the evidence in view.',80,652,32)]},
];
export const transitionBefore=.35,transitionAfter=.85;
function stateAt(t:number){
 for(let i=1;i<timing.scenes.length;i++){
  const boundary=timing.scenes[i];if(t>=boundary-transitionBefore&&t<boundary+transitionAfter)return {from:i-1,to:i,u:(t-boundary+transitionBefore)/(transitionBefore+transitionAfter),boundary};
 }
 let index=0;for(let i=1;i<timing.scenes.length;i++)if(t>=timing.scenes[i])index=i;
 return {from:index,to:index,u:1,boundary:0};
}
const Text=({item,opacity=1,dx=0,dy=0}:{item:Copy;opacity?:number;dx?:number;dy?:number})=><text x={item.x+dx} y={item.y+dy} fontSize={item.size} fill={item.color||muted} fontWeight={item.weight||400} textAnchor={item.anchor||'start'} opacity={opacity}>{item.text}</text>;
function Diagram({scene,t,alpha}:{scene:number;t:number;alpha:number}){
 const elapsed=t-timing.scenes[scene];const reveal=ease((elapsed-(scene===0?4.2:.4))/1.0);
 if(scene===0)return <g opacity={alpha}><path d="M80 490 H1520" fill="none" stroke="#dce4ef" strokeWidth="4"/><path d="M80 490 H1520" fill="none" stroke={blue} strokeWidth="4" strokeDasharray="1440" strokeDashoffset={1440*(1-reveal)}/>{[80,835].map((x,i)=><circle key={i} cx={x} cy="490" r={9*ease(reveal*2-i*.8)} fill={i?green:blue}/>)}</g>;
 if(scene===1)return <g opacity={alpha}><path d="M880 428 H967 M954 417 L967 428 L954 439" fill="none" stroke={blue} strokeWidth="4" strokeDasharray="135" strokeDashoffset={135*(1-reveal)}/></g>;
 if(scene===2)return <g opacity={alpha}>{Array.from({length:6},(_,i)=><g key={i} opacity={ease((elapsed-.6-i*.12)/.4)}><rect x={110+i*97} y="364" width="70" height="83" rx="7" fill="#ecf4ff" stroke="#95bdef" strokeWidth="2"/><path d={`M${126+i*97} 388 H${164+i*97} M${126+i*97} 404 H${158+i*97} M${126+i*97} 420 H${148+i*97}`} stroke={blue} strokeWidth="3"/></g>)}{[0,1].map(i=><g key={i} opacity={ease((elapsed-1.3-i*.25)/.45)}><rect x={860+i*132} y="364" width="100" height="83" rx="8" fill="#edf8f0" stroke="#9bcea9" strokeWidth="2"/><path d={`M${885+i*132} 405 l14 14 l27 -32`} fill="none" stroke={green} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/></g>)}</g>;
 return null;
}
export function Frame({frame}:{frame:number}){
 const t=frame/60,{from,to,u}=stateAt(t),moving=from!==to,q=ease(u),a=scenes[from],b=scenes[to];
 const morph=a.panels.map((p,i)=>{const v=b.panels[i];return {x:mix(p.x,v.x,q),y:mix(p.y,v.y,q),w:mix(p.w,v.w,q),h:mix(p.h,v.h,q),color:colorMix(p.color,v.color,q),alpha:mix(p.alpha,v.alpha,q)}});
 if(moving&&to===5){const fold=ease(u/.45),grow=ease((u-.45)/.55);morph[2]={...morph[2],x:mix(a.panels[2].x,b.panels[2].x,fold),w:mix(a.panels[2].w,b.panels[2].w,fold),y:mix(a.panels[2].y,b.panels[2].y,grow),h:mix(a.panels[2].h,b.panels[2].h,grow)};}
 const oldOpacity=moving?1-ease((u-.22)/.24):0,newOpacity=moving?ease((u-.60)/.30):1;
 const common=new Set(a.copy.filter(x=>x.shared&&b.copy.some(y=>y.shared===x.shared&&y.text===x.text)).map(x=>x.shared!));
 const headerIn=ease((t-3.60)/.5),bodyIn=ease((t-3.68)/.6),out=ease((t-(timing.outro-.16))/.46),headerOut=ease((t-(timing.outro-.16))/.16);
 const drawCopy=(scene:Scene,alpha:number)=>scene.copy.filter(item=>!common.has(item.shared||'')).map((item,i)=>{
  const p=item.panel,dx=p===undefined?0:morph[p].x-scene.panels[p].x,dy=p===undefined?0:morph[p].y-scene.panels[p].y;
  const visibleAlpha=moving&&to===5&&scene===b&&p===2?alpha*ease((u-.84)/.16):alpha;
  return <Text key={i} item={item} opacity={visibleAlpha} dx={dx} dy={dy}/>;
 });
 return <svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900" role="img" aria-label={`Gemini 4 Argon: ${b.header}`}>
 <defs><linearGradient id="theme"><stop offset="0%" stopColor="#0062cc"/><stop offset="50%" stopColor="#208235"/><stop offset="100%" stopColor="#d92820"/></linearGradient>
 <clipPath id="headerClip"><rect x="140" y="32" width={1364*headerIn*(1-headerOut)} height="82"/></clipPath><clipPath id="bodyClip"><rect x="76" y="135" width={1448*bodyIn*(1-out)} height="665"/></clipPath>
 <linearGradient id="progress"><stop offset="0%" stopColor="#007aff"/><stop offset="50%" stopColor="#34c759"/><stop offset="100%" stopColor="#ff3b30"/></linearGradient><clipPath id="progressClip"><rect x="0" y="892.5" width={1600*clamp(frame/(timing.durationInFrames-1))} height="7.5"/></clipPath></defs>
 <g fontFamily="DejaVu Sans, sans-serif"><g clipPath="url(#headerClip)" transform={`translate(${48*(1-headerIn)-24*headerOut} 0)`}>
 {moving&&<text x={140-20*ease(u)} y="91" fontSize="36" fontWeight="700" fill="url(#theme)" opacity={1-ease((u-.28)/.20)}>{a.header}</text>}
 <text x={140+(moving?20*(1-ease((u-.5)/.5)):0)} y="91" fontSize="36" fontWeight="700" fill="url(#theme)" opacity={moving?ease((u-.5)/.2):1}>{b.header}</text></g>
 <g clipPath="url(#bodyClip)" transform={`translate(${64*(1-bodyIn)-48*out} ${-12*out})`}>
 {morph.map((p,i)=><g key={i} data-shared-panel={i} opacity={p.alpha}><rect x={p.x} y={p.y} width={p.w} height={Math.max(p.h,.01)} rx={Math.min(24,p.h/2)} fill="white" stroke="#dce4ef" strokeWidth="2"/>{p.h>48&&<rect x={p.x} y={p.y+24} width="5" height={p.h-48} rx="2.5" fill={p.color}/>}</g>)}
 {moving&&<Diagram scene={from} t={t} alpha={oldOpacity}/>}<Diagram scene={to} t={t} alpha={newOpacity}/>
 {moving&&drawCopy(a,oldOpacity)}{drawCopy(b,newOpacity)}
 {[...common].map(id=>{const s=a.copy.find(x=>x.shared===id)!,v=b.copy.find(x=>x.shared===id)!;return <Text key={id} item={{...s,x:mix(s.x,v.x,q),y:mix(s.y,v.y,q),size:mix(s.size,v.size,q),weight:Math.round(mix(s.weight||400,v.weight||400,q)),color:colorMix(s.color||muted,v.color||muted,q)}}/>})}
 </g></g><rect x="0" y="892.5" width="1600" height="7.5" fill="#e2e8f0"/><rect x="0" y="892.5" width="1600" height="7.5" fill="url(#progress)" clipPath="url(#progressClip)"/>
 </svg>;
}
export const Video=()=>{const frame=useCurrentFrame();return <AbsoluteFill style={{background:'#f7f9fc'}}><BrandCanvas time={frame/60}/><div style={{position:'absolute',width:1600,height:900,transform:'scale(.8)',transformOrigin:'top left'}}><Frame frame={frame}/></div><Audio src={staticFile('review-audio.wav')}/></AbsoluteFill>};
