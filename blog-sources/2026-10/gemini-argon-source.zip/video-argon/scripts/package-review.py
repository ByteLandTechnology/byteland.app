"""Package current editable review sources only; no dependencies or frame caches."""
from pathlib import Path
import hashlib,json,zipfile
P=Path(__file__).resolve().parents[1];D=P.parent/'deliverables/video'
v=json.loads((P/'qa/validation.json').read_text());assert not v['sampled_visual_inspection']['inspection_pending']
for name in ['validation.json','source-map.json','license-check.json','bookend-integrity.json','caption-validation.json','final-audio-levels.json']:(D/name).write_bytes((P/'qa'/name).read_bytes())
(D/'README.md').write_bytes((P/'README.md').read_bytes());(D/'narration-script.txt').write_bytes((P/'audio/narration-script.txt').read_bytes())
roots={'README.md','package.json','package-lock.json','tsconfig.json','build-brand.cjs','export.cjs','render-frames.py','requirements.txt','.gitignore'}
qa={'validation.json','source-map.json','license-check.json','brand-integrity.json','bookend-integrity.json','caption-validation.json','final-audio-levels.json','audio-analysis.json','audio-mastering.json','final-probe.json','tool-versions.txt','typecheck.log','native-render.log','narration-generation.log','text-bounds.json','final-transition-fix.json','language-review.json'}
files=[]
for p in P.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(P);parts=rel.parts
 if any(x in parts for x in ['node_modules','out','__pycache__','.mesa-cache']):continue
 keep=parts[0] in ['brand','src','scripts','audio','captions'] and p.name!='brand-render-data.json'
 if parts[:2]==('audio','generated-sentences') and p.name in ['narration.wav','narration-timing.partial.json']:keep=False
 keep=keep or (parts[0]=='qa' and p.name in qa)
 keep=keep or (len(parts)==1 and (p.name in roots or p.name.startswith('LICENSE')))
 keep=keep or (parts[0]=='renderer' and p.suffix in ['.py','.cjs'])
 if keep:files.append(p)
archive=D/'gemini-argon-editable-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(files):z.write(p,'video-argon/'+str(p.relative_to(P)))
with zipfile.ZipFile(archive)as z:
 assert z.testzip() is None
 assert not any('node_modules' in x or '/out/' in x or x.endswith('.onnx') for x in z.namelist())
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(D.iterdir())if p.is_file()and p.name!='manifest.json'}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
