"""Original motion cues plus optional newly generated narration. No network access.
The narration input is a mono 24 kHz full-timeline WAV created for this review.
"""
from pathlib import Path
import wave,json,hashlib
import numpy as np
P=Path(__file__).resolve().parents[1]
T=json.loads((P/'src/timing.json').read_text());SR=24000;N=round(T['durationInFrames']/T['fps']*SR)
rng=np.random.default_rng(101426);fx=np.zeros(N);events=[]
def add(start,x,kind):
 i=round(start*SR);n=min(len(x),N-i);fx[i:i+n]+=x[:n];events.append({'start':start,'duration':n/SR,'kind':kind})
def pop(start,f=920,d=.11,amp=.055):
 t=np.arange(round(SR*d))/SR;env=(1-np.exp(-t/.002))*np.exp(-t/.026)*np.minimum(1,(d-t)/.016)
 phase=2*np.pi*f*(t+.0035*(1-np.exp(-t/.022)))
 add(start,amp*env*(np.sin(phase)+.12*np.sin(2*phase))/1.12,'rounded pop')
def cue(start,f=1046.5,d=.22,amp=.043):
 t=np.arange(round(SR*d))/SR;env=(1-np.exp(-t/.004))*np.exp(-t/.058)*np.minimum(1,(d-t)/.035)
 add(start,amp*env*(np.sin(2*np.pi*f*t)+.13*np.sin(4*np.pi*f*t))/1.13,'bright short cue')
def swish(start,d=.23,amp=.030):
 n=round(d*SR);z=rng.normal(0,1,n);freq=np.fft.rfftfreq(n,1/SR)
 band=np.exp(-.5*((freq-2600)/950)**2);band[freq<650]=0
 z=np.fft.irfft(np.fft.rfft(z)*band,n=n);z/=max(abs(z))
 add(start,amp*z*np.sin(np.pi*np.arange(n)/(n-1))**2,'airy short swish')
pop(.20,783.99);pop(.45,987.77,amp=.049);cue(1.08,1174.66,d=.18,amp=.035)
swish(2.82,.25);pop(3.52,1318.51,amp=.036)
for i,start in enumerate(T['scenes'][1:]):
 swish(start,.16,.018);pop(start+.09,[783.99,987.77,1174.66][i%3],.09,.035)
for start in [38.60,39.05,39.50]:pop(start,1046.5,.08,.022)
swish(71.30,.26,.033);cue(71.76,1046.5,.22,.044);cue(71.97,1318.51,.23,.039);cue(72.20,1567.98,.27,.035)
swish(73.47,.30,.018);pop(74.17,1567.98,.12,.037)
voice=np.zeros(N);narration=P/'audio/narration.wav';narration_present=narration.exists()
if narration_present:
 with wave.open(str(narration),'rb') as f:
  assert f.getframerate()==SR and f.getnchannels()==1 and f.getsampwidth()==2, 'Need mono 24 kHz int16 full-timeline narration'
  a=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype(float)/32768
 assert len(a)<=N or np.max(np.abs(a[N:]))==0, 'Only trailing silence may be trimmed'
 voice[:min(len(a),N)]=a[:N]
 # Keep narration beneath -3 dBFS without boosting a quiet recording blindly.
 voice*=min(1,0.707/max(1e-9,float(max(abs(voice)))))
window=1200
levels=np.array([np.sqrt(np.mean(voice[i:i+window]**2)) for i in range(0,N,window)])
env=np.interp(np.arange(N),np.arange(len(levels))*window,levels)
fx*=1-.72*np.clip(env/.04,0,1)
mix=voice+fx
assert np.isfinite(mix).all() and max(abs(mix))<.98
for path,x in [(P/'public/review-audio.wav',mix),(P/'audio/original-sfx.wav',fx)]:
 path.parent.mkdir(exist_ok=True)
 with wave.open(str(path),'wb') as f:
  f.setnchannels(1);f.setsampwidth(2);f.setframerate(SR);f.writeframes(np.round(np.clip(x,-1,.999969)*32768).astype('<i2').tobytes())
report={'sample_rate':SR,'duration':N/SR,'narration_present':narration_present,'trailing_silence_trim_samples':max(0,len(a)-N) if narration_present else 0,'narration_source_sha256':hashlib.sha256(narration.read_bytes()).hexdigest() if narration_present else None,'synth_seed':101426,'fx_source':'original mathematical synthesis in build-audio.py','events':events,'mix_peak_dbfs':float(20*np.log10(max(abs(mix)))),'clipped_samples':int(np.sum(abs(mix)>=1)),'listening_performed':False,'listening_limitation':'Objective analysis only; no actual audio playback available.'}
(P/'qa/audio-analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
