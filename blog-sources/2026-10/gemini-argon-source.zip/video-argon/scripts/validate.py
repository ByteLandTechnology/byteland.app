"""Validate final encoded movie, speech sample timing, captions and sampled frames.
No auditory review, ASR check, browser playback or Gemini inference is claimed.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import hashlib,json,re,subprocess,wave,zipfile
import numpy as np
P=Path(__file__).resolve().parents[1];D=P.parent/'deliverables/video';movie=D/'gemini-argon-review.mp4'
T=json.loads((P/'src/timing.json').read_text());duration=T['durationInFrames']/60
probe=subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','format=duration,size:stream=codec_name,width,height,avg_frame_rate,nb_read_frames,pix_fmt,sample_rate,channels','-of','json',str(movie)],text=True);(P/'qa/final-probe.json').write_text(probe)
j=json.loads(probe);v=j['streams'][0];assert int(v['nb_read_frames'])==T['durationInFrames'] and float(j['format']['duration'])>=60
assert v['width']==1280 and v['height']==720 and v['avg_frame_rate']=='60/1' and v['pix_fmt']=='yuv420p'
subprocess.run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-'],check=True)
log=subprocess.run(['ffmpeg','-hide_banner','-i',str(movie),'-af','ebur128=peak=true','-f','null','-'],check=True,capture_output=True,text=True).stderr;(P/'qa/final-audio-loudness.log').write_text(log)
summary=log[log.rfind('Summary:'):];audio={'integrated_lufs':float(re.search(r'I:\s+(-?[\d.]+) LUFS',summary).group(1)),'loudness_range_lu':float(re.search(r'LRA:\s+(-?[\d.]+) LU',summary).group(1)),'true_peak_dbtp':float(re.search(r'Peak:\s+(-?[\d.]+) dBFS',summary).group(1))}
assert -19<=audio['integrated_lufs']<=-17 and audio['true_peak_dbtp']<=-.9
(P/'qa/final-audio-levels.json').write_text(json.dumps(audio,indent=2)+'\n')
def pcm(path):
 with wave.open(str(path),'rb') as f:
  assert f.getframerate()==24000 and f.getnchannels()==1 and f.getsampwidth()==2
  return np.frombuffer(f.readframes(f.getnframes()),dtype='<i2')
stem=pcm(P/'audio/narration.wav');assert len(stem)==round(duration*24000)
nt=json.loads((P/'audio/narration-timing.json').read_text());same=True
for segment in nt['segments']:
 for s in segment['sentences']:
  clip=pcm(P/'audio/generated-sentences'/Path(s['wav']).name)
  same=same and np.array_equal(clip,stem[s['startSample']:s['endSample']])
assert same
source_clipping=int(np.count_nonzero((stem==-32768)|(stem==32767)));assert source_clipping==0
narr={'samples':len(stem),'duration':len(stem)/24000,'sample_rate':24000,'sentence_clips_match_timeline':same,'sample_peak_dbfs':float(20*np.log10(np.max(abs(stem.astype(float)))/32768)),'rms_dbfs':float(20*np.log10(np.sqrt(np.mean((stem.astype(float)/32768)**2)))),'clipped_samples':source_clipping,'listening_performed':False,'asr_review':False}
(P/'audio/narration-validation.json').write_text(json.dumps(narr,indent=2)+'\n')
counts={};cps={}
for language in ['en','zh-Hans','zh-Hant','ja']:
 s=(D/f'captions.{language}.vtt').read_text();assert s.startswith('WEBVTT\n')
 blocks=s.split('\n\n')[1:];previous=0;count=0;maxcps=0
 for block in blocks:
  if not block.strip():continue
  lines=block.splitlines();stamp=lines[1];a,b=stamp.split(' --> ')
  def seconds(x):
   h,m,s=x.split(':');return int(h)*3600+int(m)*60+float(s)
  start,end=seconds(a),seconds(b);assert previous<=start<end<=duration;previous=end
  content=' '.join(lines[2:]);assert content and len(lines[2:])<=3
  maxcps=max(maxcps,len(content)/(end-start));count+=1
 counts[language]=count;cps[language]=round(maxcps,2)
assert set(counts.values())=={15}
caption={'cue_counts':counts,'maximum_characters_per_second':cps,'overlaps':0,'out_of_bounds':0,'languages':['en','zh-Hans','zh-Hant','ja'],'timing_basis':'Measured generated sentence sample counts plus ≤80ms caption tail','translation_review':'Assistant translations; no separate native-speaker review'}
(P/'qa/caption-validation.json').write_text(json.dumps(caption,indent=2)+'\n')
scenes=[480,1080,1740,2520,3300,3960];bookends=[0,26,84,155,214,240,4300,4380,4440,4467];offsets=[-.5,-.1,0,.25,.55,.85];boundaries=T['scenes'][1:]
keys=sorted(set(scenes+bookends+[round((b+d)*60) for b in boundaries for d in offsets]));selector='+'.join('eq(n\\,{})'.format(f) for f in keys)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(movie),'-vf','select='+selector,'-fps_mode','vfr','-frames:v',str(len(keys)),str(P/'qa/sample-%03d.png')],check=True)
for index,f in enumerate(keys,1):(P/f'qa/sample-{index:03}.png').replace(P/f'qa/encoded-{f:04}.png')
def sheet(keys,name,cols=2):
 rows=(len(keys)+cols-1)//cols;s=Image.new('RGB',(640*cols,360*rows),'white');draw=ImageDraw.Draw(s)
 for i,f in enumerate(keys):
  s.paste(Image.open(P/f'qa/encoded-{f:04}.png').convert('RGB').resize((640,360)),((i%cols)*640,(i//cols)*360))
  draw.text(((i%cols)*640+553,(i//cols)*360+337),f'{f/60:.2f} s',fill='#172033')
 s.save(D/name,quality=94)
sheet(scenes,'scene-contact-sheet.jpg')
sheet(bookends,'brand-contact-sheet.jpg',2)
for b in boundaries:sheet([round((b+d)*60)for d in offsets],f'transition-{b:02}-encoded.jpg')
Image.open(P/'qa/encoded-0480.png').convert('RGB').save(D/'poster.jpg',quality=94)
source=(P/'src/Video.tsx').read_text();assert 'END-TO-END' not in source and 'height="7.5"' in source and 'y="892.5"' in source
brand=json.loads((P/'src/brand-render-data.json').read_text())['states'];corner=brand[240:round(T['outro']*60)]
assert all(abs(x['center'][0]-78)<.0001 and abs(x['logoScale']-.22)<.0001 for x in corner)
angles=[x['angle'] for x in corner];assert all(b>a for a,b in zip(angles,angles[1:]))
brand_integrity=json.loads((P/'qa/brand-integrity.json').read_text());assert all(x['identical_to_approved_source'] for x in brand_integrity)
report={'revision':'v1','status':'Review draft; not approved for production publication','movie_sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'duration_seconds':float(j['format']['duration']),'exact_video_duration_seconds':duration,'frame_count':int(v['nb_read_frames']),'fps':60,'width':1280,'height':720,'video_codec':'H.264 yuv420p','audio_codec':'AAC mono 24 kHz','render_method':'Native React SVG export + librsvg/Cairo + analytical GLSL SDF through EGL Mesa llvmpipe + FFmpeg; not browser Remotion','remotion_version':'4.0.534','typecheck':'passed','video_decode':'Complete movie decoded successfully with FFmpeg','caption_validation':caption,'audio':{'voice':'Kokoro af_heart stock voice','original_synthesized_sfx':True,**audio,'source_narration_clipped_samples':source_clipping,'sentence_clips_match_timeline':same,'listening_performed':False,'asr_review':False},'brand':{'approved_files_unchanged':True,'continuous_corner_rotation':True,'bookend_relative_timing_preserved':True,'progress_flush_bottom':True,'subtitles_burned_in':False},'sampled_visual_inspection':{'scene_frames':scenes,'bookend_frames':bookends,'boundary_seconds':boundaries,'offsets_seconds':offsets,'encoded_frame_samples':len(keys),'inspection_pending':True},'model_inference_run':False,'no_paid_services':True,'committed_or_pushed':False,'production_publication':False,'limitations':['No browser rendering or playback; native rendering only.','No audio listening or independent ASR check.','Assistant-generated captions without separate native-speaker review.','Selected public reactions are anecdotes, not a representative survey.','Video uses source review; no Gemini inference or vendor case replication.']}
(P/'qa/validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
