"""Mux the native EGL/React-SVG movie with the newly prepared soundtrack."""
from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parents[1];t=json.loads((p/'src/timing.json').read_text());duration=t['durationInFrames']/t['fps']
out=p.parent/'deliverables/video';out.mkdir(parents=True,exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'out/video-silent.mp4'),'-i',str(p/'public/review-audio.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-af','apad','-t',str(duration),'-movflags','+faststart',str(out/'gemini-argon-review.mp4')],check=True)
