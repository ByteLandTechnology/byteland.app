# Gemini 4 Argon: promise, evidence, and trade-offs

Review draft, 14 October 2026. Not approved for ByteLand production publication.

## Deliverables

- `../deliverables/video/gemini-argon-review.mp4`: 1280 × 720, 60 fps, 4,468 frames, 74.4667 seconds.
- Natural English synthetic narration using the licensed stock Kokoro `af_heart` voice.
- Four external caption tracks: English, Simplified Chinese, Traditional Chinese, Japanese.
- Six content-driven scenes with an original release timeline, API input/output diagram, six-proposal/two-shipped illustration, distinct ranking cards, attributed early reactions, and a task-selection checklist.
- The approved analytical three-leaf SDF logo and E3 wordmark, B5 intro/outro, one rotating corner mark, short themed chapter headers and a flush bottom progress line.
- Original mathematically synthesized pops, airy swishes, and bright cues. No music bed or third-party footage.

This is an evidence-led review. No Gemini model inference or independent reproduction of the quoted case study was performed. The two Reddit reports are selected anecdotes, not a survey or public consensus. The two benchmark ranks come from different test suites and are not directly comparable scores.

## Actual rendering route

The delivered MP4 uses a native React-SVG → librsvg/Cairo → analytical GLSL SDF through EGL/Mesa → FFmpeg pipeline. `src/Video.tsx` is an editable Remotion composition, exported through the same `Frame` component. This is not a browser Remotion render. Chromium, a file browser protocol and sockets were not used.

Remotion, its CLI and renderer are pinned to 4.0.534. The installed license was read and hashed again; the user-confirmed company size of at most three employees matches its Free License eligibility. See `qa/license-check.json` and `LICENSE-Remotion-4.0.534.md`. No paid rendering, inference, TTS, GitHub Actions or license purchase was used.

## Sources and scope

Narration and graphics paraphrase these sources. Full claim mapping is in `qa/source-map.json`. The production article supplies broader mainstream-media coverage; the film uses primary specifications, primary evaluations and direct public user reports.

1. Google's September 30 unveiling: https://blog.google/innovation-and-ai/models-and-research/gemini-models/gemini-4-argon/
2. Google's October 13 wider rollout: https://blog.google/intl/en-in/products/introducing-gemini-4-argon/
3. Stable API, modalities and context: https://ai.google.dev/gemini-api/docs/models/gemini-4-argon
4. Shared input/thinking/output budget: https://ai.google.dev/gemini-api/docs/latest-model
5. Google's eleven-hour engineering case: https://developers.googleblog.com/optimizing-a-200000-line-python-codebase-overnight-with-gemini-4-argon/
6. Vals Index v2.1, updated October 13: https://www.vals.ai/benchmarks/vals_index
7. Artificial Analysis high-effort Argon page, checked October 14: https://artificialanalysis.ai/models/gemini-4-argon
8. u/AccomplishedChip3494, October 13, r/GeminiAI: https://www.reddit.com/r/GeminiAI/comments/1x50usi/comment/pgi9sl0/
9. u/this-is-hilarours, October 13, r/google_antigravity: https://www.reddit.com/r/google_antigravity/comments/1x539fq/gemini_4_argon_initial_review/

Google's product pitch and selected engineering case are vendor evidence. Vals and Artificial Analysis operate separate benchmark suites. The positive Reddit report calls its results preliminary; the critical report is one feature-planning comparison using an LLM judge, and other commenters challenge its method. The final checklist is editorial advice, not measured results from this project. No source passage is quoted verbatim.

## Rebuild

Inspect scripts before execution. The validated cloud environment already had all dependencies. A new machine needs Node, Python, NumPy, Pillow, librsvg, Cairo, EGL/Mesa and FFmpeg. Dependency versions and notices are supplied.

```sh
npm ci --ignore-scripts
node build-brand.cjs
npm run typecheck
python3 scripts/build-audio.py
python3 scripts/master-audio.py
python3 scripts/build-captions.py
node export.cjs
python3 render-frames.py
python3 scripts/render-film.py
python3 scripts/mux.py
python3 scripts/validate.py
```

The included `audio/narration.wav` is the complete validated speech stem. Rebuilding from it does not need any neural model. Fresh speech is optional: put the specified model and voice bank in `tts/models/`, install the pinned narration requirements in a separate environment, and run `scripts/generate-narration.py`. `KOKORO_HOME` can point to an existing read-only model/runtime location; caches and outputs are written here. The fresh-speech script was actually executed with the existing offline Kokoro installation.

`npm run preview` and `npm run render:remotion` are supplied for machines on which normal Chromium is permitted. Neither browser route was run or validated in this task. Do not use them to bypass an access restriction.

## Editable source map

- `src/Video.tsx`: scenes, copy, diagrams, shared panel transitions and progress.
- `src/timing.json`: exact timeline.
- `src/BrandCanvas.tsx`, `brand/`, `renderer/`: original approved logo, wordmark and native renderer.
- `build-brand.cjs`: approved geometry with extended body hold; outro motion retains its original relative timing.
- `audio/narration-script.json` and `.txt`: full spoken script.
- `scripts/generate-narration.py`: offline stock-voice synthesis and measured sentence timings.
- `scripts/build-audio.py`, `scripts/master-audio.py`: deterministic original sound effects, speech ducking, two-pass loudness mastering.
- `captions/translations.json`: all four editable caption languages.
- `scripts/build-captions.py`: sentence-clip timing to external VTT.
- `qa/`: source mapping, licensing, technical audio, caption, frame and final-file validation.

The source archive excludes dependencies, model weights, caches, generated shader state, and duplicate frame dumps. The included script regenerates shader state from the editable brand source.

## Validation boundaries

The movie is fully decoded with FFmpeg, frames are counted, and encoded scene/bookend/transition samples are inspected. This is sampled visual inspection, not a claim of complete perceptual playback. Audio is checked for sample clipping, loudness, true peak and timing. No actual audio listening or independent ASR check is claimed. Captions use measured sentence-clip timings; translations are assistant-generated without a separate native-speaker review.

The English script has a partial clarity and sentence-length review in `qa/language-review.json`. No complete ASD-STE100 Issue 9 dictionary/grammar review or compliance certification is claimed.

See `qa/validation.json` for actual measured results. No production commit, push, deploy or publication was performed by this video task.

## Rights

Repository brand/source license: `LICENSE-ByteLand`. Exo 2-derived wordmark outlines: SIL Open Font License in `brand/Exo2-OFL.txt`. Body text: DejaVu Sans, notice in `LICENSE-DejaVu.txt`. Remotion and narration dependencies retain their separate license notices. No third-party music, photos, footage or screenshots are included.
