from pathlib import Path
import subprocess,json,wave,numpy as np,hashlib,re
P=Path(__file__).resolve().parents[1];run=lambda a:subprocess.run(a,check=True,capture_output=True,text=True)
v=P/'tokenmaxxing-bert-v12.mp4';clip=P/'tokenmaxxing-bert-ending-v12.mp4'
for f in [v,clip]:run(['ffmpeg','-v','error','-threads','2','-i',str(f),'-f','null','-'])
streams=[run(['ffmpeg','-v','error','-i',str(f),'-map','0:v:0','-c','copy','-f','hash','-hash','sha256','-']).stdout for f in [P/'source/base-v11.mp4',v]];assert streams[0]==streams[1]
probe=json.loads(run(['ffprobe','-v','error','-show_entries','format=duration:stream=codec_name,nb_frames,avg_frame_rate,start_time','-of','json',str(v)]).stdout);assert probe['streams'][0]['nb_frames']=='4048'
run(['ffmpeg','-v','error','-y','-i',str(v),'-vn','-ar','24000','-ac','1','-c:a','pcm_s16le',str(P/'qa/decoded-v12.wav')])
with wave.open(str(P/'qa/decoded-v12.wav')) as w:x=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(float)/32768
log=run(['ffmpeg','-hide_banner','-i',str(v),'-af','ebur128=peak=true','-f','null','-']).stderr;summary=log[log.rfind('Summary:'):]
r={'full_decode_passed':True,'preview_decode_passed':True,'video_stream_identical_to_v11':True,'probe':probe,'integrated_lufs':float(re.search(r'I:\s+(-?[\d.]+) LUFS',summary).group(1)),'true_peak_dbtp':float(re.search(r'Peak:\s+(-?[\d.]+) dBFS',summary).group(1)),'clipped_samples':int(sum(abs(x)>=1)),'video_sha256':hashlib.sha256(v.read_bytes()).hexdigest(),'listening_performed':False};(P/'qa/validation-v12.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
