import React from 'react';
import {AbsoluteFill,Audio,useCurrentFrame,staticFile} from 'remotion';
import {BrandCanvas} from './BrandCanvas';
import timing from './timing.json';
export const durationInFrames=timing.durationInFrames;
export const contentReady=true;
const blue='#007aff',green='#258b40',red='#d82b22',ink='#172033',muted='#5c687b';
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const ease=(x:number)=>{const u=clamp(x);return u*u*u*(u*(u*6-15)+10)};
const mix=(a:number,b:number,u:number)=>a+(b-a)*u;
const colorMix=(a:string,b:string,u:number)=>'#'+[1,3,5].map(i=>Math.round(mix(parseInt(a.slice(i,i+2),16),parseInt(b.slice(i,i+2),16),u)).toString(16).padStart(2,'0')).join('');
type Panel={x:number;y:number;w:number;h:number;color:string};
type Copy={text:string;x:number;y:number;size:number;color?:string;weight?:number;panel?:number;shared?:string};
type Scene={header:string;panels:Panel[];copy:Copy[]};
const panel=(x:number,y:number,w:number,h:number,color=blue):Panel=>({x,y,w,h,color});
const text=(text:string,x:number,y:number,size=28,color=muted,weight=400,p?:number,shared?:string):Copy=>({text,x,y,size,color,weight,panel:p,shared});
const P:Panel[][]=[
 [panel(80,430,440,210,blue),panel(580,430,440,210,green),panel(1080,430,440,210,red)],
 [panel(80,300,440,290,blue),panel(580,300,440,290,green),panel(1080,300,440,290,red)],
 [panel(80,300,440,290,blue),panel(580,300,440,290,green),panel(1080,300,440,290,red)],
 [panel(80,270,1440,100,blue),panel(80,395,1440,100,green),panel(80,520,1440,100,red)],
 [panel(80,320,420,235,blue),panel(590,320,420,235,green),panel(1100,320,420,235,red)],
 [panel(80,255,1440,105,blue),panel(80,385,1440,105,green),panel(80,515,1440,105,red)],
];
const scenes:Scene[]=[
 {header:'FASTER TOKENIZATION',panels:P[0],copy:[
 text('HUGGING FACE · OCTOBER 15, 2026',80,214,28,blue,700),text('Less work. Same contract.',76,316,64,ink,700),text('A new BERT optimization proposal deserves careful validation.',80,377,30),
 text('Normalize',110,493,37,blue,700,0),text('Prepare the text',110,550,28,muted,400,0),
 text('Tokenize',610,493,37,green,700,1),text('Produce model inputs',610,550,27,muted,400,1),
 text('Verify',1110,493,37,red,700,2),text('Keep behavior correct',1110,550,27,muted,400,2),text('Draft pull request #2508 · not a stable v1 release',80,708,29,ink,700)]},
 {header:'AVOID UNNECESSARY WORK',panels:P[1],copy:[
 text('Optimize the path before the model.',80,218,43,ink,700),
 text('ASCII ranges',110,360,34,blue,700,0),text('Check blocks of bytes',110,423,27,muted,400,0),text('Skip eligible work',110,480,28,muted,400,0),
 text('Unicode pages',610,360,32,green,700,1),text('Cache character decisions',610,423,25,muted,400,1),text('Reuse nearby results',610,480,27,muted,400,1),
 text('Lazy output',1110,360,34,red,700,2),text('Wait for a real change',1110,423,26,muted,400,2),text('Then allocate output',1110,480,27,muted,400,2),text('The model and its learned weights do not change.',80,664,30,ink,700)]},
 {header:'MEASURE YOUR WORKLOAD',panels:P[2],copy:[
 text('The input distribution determines the gain.',80,218,41,ink,700),
 text('Language',110,360,34,blue,700,0),text('English and source code',110,423,25,muted,400,0),text('Chinese and mixed scripts',110,480,24,muted,400,0),
 text('Length',610,360,34,green,700,1),text('Queries and short labels',610,423,25,muted,400,1),text('Documents and batches',610,480,26,muted,400,1),
 text('Pipeline',1110,360,34,red,700,2),text('Preprocess + model + I/O',1110,423,24,muted,400,2),text('Measure end to end',1110,480,28,muted,400,2),text('A tokenizer speedup is not the same as a service speedup.',80,664,29,ink,700)]},
 {header:'PRESERVE THE CONTRACT',panels:P[3],copy:[
 text('Matching token IDs are necessary, but not always sufficient.',80,210,35,ink,700),
 text('Token IDs',110,332,32,blue,700,0),text('The model receives the same sequence',660,332,28,ink,400,0),
 text('Source offsets',110,457,32,green,700,1),text('Highlights still point into the original text',660,457,27,ink,400,1),
 text('Configuration',110,582,32,red,700,2),text('Special tokens, truncation and padding match',660,582,25,ink,400,2),
 text('Test composed and decomposed accents, CJK, and controls.',80,690,28,ink,700)]},
 {header:'A REAL BASELINE TRAP',panels:P[4],copy:[
 text('Chinese spacing changes on a second normalization pass.',80,220,35,ink,700),
 text('Original text',110,376,32,blue,700,0),text('Chinese characters',110,435,28,muted,400,0),text('No added padding',110,487,27,muted,400,0),
 text('First pass',620,376,34,green,700,1),text('Add boundary spaces',620,435,26,muted,400,1),text('Prepare token splits',620,487,26,muted,400,1),
 text('Second pass',1130,376,32,red,700,2),text('Add more spaces',1130,435,28,muted,400,2),text('String equality fails',1130,487,26,muted,400,2),
 text('Observed on tokenizers 0.23.2; not a test of the optimized PR.',80,650,28,ink,700),text('Choose checks that reflect the actual output contract.',80,698,29)]},
 {header:'PROFILE, COMPARE, THEN ADOPT',panels:P[5],copy:[
 text('Make performance gains safe to use.',80,198,43,ink,700),
 text('Pin',170,320,33,blue,700,0),text('Tokenizer build and vocabulary revision',600,320,28,ink,400,0),
 text('Compare',170,450,33,green,700,1),text('Token IDs, offsets and application results',600,450,27,ink,400,1),
 text('Measure',170,580,33,red,700,2),text('Representative inputs and full-pipeline latency',600,580,25,ink,400,2),
 text('Keep the previous version available for rollback.',80,685,30,ink,700)]},
];
export const transitionBefore=.40,transitionAfter=1.00;
function stateAt(t:number){
 for(let i=1;i<timing.scenes.length;i++){const boundary=timing.scenes[i];if(t>=boundary-transitionBefore&&t<boundary+transitionAfter)return {from:i-1,to:i,u:(t-boundary+transitionBefore)/(transitionBefore+transitionAfter)};}
 let index=0;for(let i=1;i<timing.scenes.length;i++)if(t>=timing.scenes[i])index=i;
 return {from:index,to:index,u:1};
}
const Text=({item,opacity=1,dx=0,dy=0}:{item:Copy;opacity?:number;dx?:number;dy?:number})=><text x={item.x+dx} y={item.y+dy} fontSize={item.size} fill={item.color||muted} fontWeight={item.weight||400} opacity={opacity}>{item.text}</text>;
export function Frame({frame}:{frame:number}){
 const t=frame/timing.fps,{from,to,u}=stateAt(t),moving=from!==to,q=ease(u),a=scenes[from],b=scenes[to];
 const morph=a.panels.map((p,i)=>{const v=b.panels[i];let x=mix(p.x,v.x,q),y=mix(p.y,v.y,q),w=mix(p.w,v.w,q),h=mix(p.h,v.h,q);
  // Cards flatten into separate rows before growing horizontally. The return
  // journey narrows the rows first, then places them along the tool path.
  if(moving&&(to===3||to===5)){const fold=ease(u/.47),spread=ease((u-.47)/.53);y=mix(p.y,v.y,fold);h=mix(p.h,v.h,fold);x=mix(p.x,v.x,spread);w=mix(p.w,v.w,spread);}
  if(moving&&to===4){const fold=ease(u/.47),place=ease((u-.47)/.53);x=mix(p.x,v.x,fold);w=mix(p.w,v.w,fold);y=mix(p.y,v.y,place);h=mix(p.h,v.h,place);}
  return {x,y,w,h,color:colorMix(p.color,v.color,q)};});
 // Numeric benchmark copy exits fully before harness labels enter. All other
 // boundaries have a brief overlap, held at readable sizes inside their panels.
 const foldTransition=moving&&to>=3;
 const oldOpacity=moving?1-ease((u-(foldTransition?.08:from===0?.12:.27))/(foldTransition?.18:from===0?.22:.28)):0;
 const newOpacity=moving?ease((u-(foldTransition?.78:.50))/(foldTransition?.20:.29)):1;
 const common=new Set(a.copy.filter(x=>x.shared&&b.copy.some(y=>y.shared===x.shared&&y.text===x.text)).map(x=>x.shared!));
 const headerIn=ease((t-3.60)/.5),bodyIn=ease((t-3.68)/.6),out=ease((t-(timing.outro-.16))/.46),headerOut=ease((t-(timing.outro-.16))/.16);
 const drawCopy=(scene:Scene,alpha:number,isOld=false)=>scene.copy.filter(item=>!common.has(item.shared||'')).map((item,i)=>{const p=item.panel;return <Text key={i} item={item} opacity={alpha} dx={p===undefined||(isOld&&foldTransition)?0:morph[p].x-scene.panels[p].x} dy={p===undefined||(isOld&&foldTransition)?0:morph[p].y-scene.panels[p].y}/>;});
 const layerAlpha=(n:number)=>moving?(from===n?oldOpacity:to===n?newOpacity:0):(to===n?1:0);
 return <svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900" role="img" aria-label={`BERT tokenization: ${b.header}`}>
 <defs><linearGradient id="theme"><stop offset="0%" stopColor="#0062cc"/><stop offset="50%" stopColor="#208235"/><stop offset="100%" stopColor="#d92820"/></linearGradient>
 <clipPath id="headerClip"><rect x="140" y="32" width={1364*headerIn*(1-headerOut)} height="82"/></clipPath><clipPath id="bodyClip"><rect x="76" y="135" width={1448*bodyIn*(1-out)} height="665"/></clipPath>
 <linearGradient id="progress"><stop offset="0%" stopColor="#007aff"/><stop offset="50%" stopColor="#34c759"/><stop offset="100%" stopColor="#ff3b30"/></linearGradient><clipPath id="progressClip"><rect x="0" y="892.5" width={1600*clamp(frame/(timing.durationInFrames-1))} height="7.5"/></clipPath></defs>
 <g fontFamily="DejaVu Sans, sans-serif"><g clipPath="url(#headerClip)" transform={`translate(${48*(1-headerIn)-24*headerOut} 0)`}>
 {moving&&<text x={140-20*ease(u)} y="91" fontSize="36" fontWeight="700" fill="url(#theme)" opacity={1-ease((u-.28)/.20)}>{a.header}</text>}
 <text x={140+(moving?20*(1-ease((u-.5)/.5)):0)} y="91" fontSize="36" fontWeight="700" fill="url(#theme)" opacity={moving?ease((u-.5)/.2):1}>{b.header}</text></g>
 <g clipPath="url(#bodyClip)" transform={`translate(${64*(1-bodyIn)-48*out} ${-12*out})`}>
 {morph.map((p,i)=><g key={i} data-shared-panel={i}><rect x={p.x} y={p.y} width={p.w} height={p.h} rx={Math.min(24,p.h/2)} fill="white" stroke="#dce4ef" strokeWidth="2"/><rect x={p.x} y={p.y+24} width="5" height={p.h-48} rx="2.5" fill={p.color}/></g>)}
 <g opacity={layerAlpha(4)}>{[0,1].map(i=><path key={i} d={`M${morph[i].x+morph[i].w+10} ${morph[i].y+118}H${morph[i+1].x-12}m-11 -7l11 7 -11 7`} fill="none" stroke={i?red:green} strokeWidth="3" strokeLinecap="round"/>)}</g>
 <g opacity={layerAlpha(5)}>{morph.map((p,i)=><g key={i}><rect x={p.x+29} y={p.y+34} width="34" height="34" rx="8" fill={p.color} opacity=".10"/><path d={`M${p.x+37} ${p.y+51}l7 7 13 -15`} fill="none" stroke={p.color} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"/></g>)}</g>
 {moving&&drawCopy(a,oldOpacity,true)}{drawCopy(b,newOpacity)}
 {[...common].map(id=>{const s=a.copy.find(x=>x.shared===id)!,v=b.copy.find(x=>x.shared===id)!;return <Text key={id} item={{...s,x:mix(s.x,v.x,q),y:mix(s.y,v.y,q),size:mix(s.size,v.size,q),color:colorMix(s.color||muted,v.color||muted,q)}}/>})}
 </g></g><rect x="0" y="892.5" width="1600" height="7.5" fill="#e2e8f0"/><rect x="0" y="892.5" width="1600" height="7.5" fill="url(#progress)" clipPath="url(#progressClip)"/>
 </svg>;
}
export const Video=()=>{const frame=useCurrentFrame();return <AbsoluteFill style={{background:'#f7f9fc'}}><BrandCanvas time={frame/timing.fps}/><div style={{position:'absolute',width:1600,height:900,transform:'scale(.8)',transformOrigin:'top left'}}><Frame frame={frame}/></div><Audio src={staticFile('review-audio.wav')}/></AbsoluteFill>};
