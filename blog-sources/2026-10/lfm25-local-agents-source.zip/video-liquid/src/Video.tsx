import React from 'react';
import {AbsoluteFill,Audio,useCurrentFrame,staticFile} from 'remotion';
import {BrandCanvas} from './BrandCanvas';
import timing from './timing.json';
export const durationInFrames=timing.durationInFrames;
export const contentReady=true;
const blue='#007aff',green='#258b40',red='#d82b22',ink='#172033',muted='#5c687b';
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const ease=(x:number)=>{const u=clamp(x);return u*u*u*(u*(u*6-15)+10)};
const mix=(a:number,b:number,u:number)=>a+(b-a)*u;
const colorMix=(a:string,b:string,u:number)=>'#'+[1,3,5].map(i=>Math.round(mix(parseInt(a.slice(i,i+2),16),parseInt(b.slice(i,i+2),16),u)).toString(16).padStart(2,'0')).join('');
type Panel={x:number;y:number;w:number;h:number;color:string};
type Copy={text:string;x:number;y:number;size:number;color?:string;weight?:number;panel?:number;shared?:string};
type Scene={header:string;panels:Panel[];copy:Copy[]};
const panel=(x:number,y:number,w:number,h:number,color=blue):Panel=>({x,y,w,h,color});
const text=(text:string,x:number,y:number,size=28,color=muted,weight=400,p?:number,shared?:string):Copy=>({text,x,y,size,color,weight,panel:p,shared});
const P:Panel[][]=[
 [panel(80,455,440,175,blue),panel(580,455,440,175,green),panel(1080,455,440,175,red)],
 [panel(80,310,650,260,blue),panel(760,310,390,260,green),panel(1180,310,340,260,red)],
 [panel(80,300,440,290,blue),panel(580,300,440,290,green),panel(1080,300,440,290,red)],
 [panel(80,270,1440,100,blue),panel(80,395,1440,100,green),panel(80,520,1440,100,red)],
 [panel(80,320,420,235,blue),panel(590,320,420,235,green),panel(1100,320,420,235,red)],
 [panel(80,255,1440,105,blue),panel(80,385,1440,105,green),panel(80,515,1440,105,red)],
];
const scenes:Scene[]=[
 {header:'LOCAL AGENTS',panels:P[0],copy:[
 text('LIQUID AI · OCTOBER 13, 2026',80,224,29,blue,700),text('LFM2.5-24B-A2B',76,334,82,ink,700),text('Active compute is one part of deployment.',80,402,36),
 text('24B total',110,520,42,blue,700,0,'total-weights'),text('Parameters in the model',110,576,27,muted,400,0),
 text('2.45B active',610,520,42,green,700,1),text('Per token, approximately',610,576,27,muted,400,1),
 text('Local agents',1110,520,39,red,700,2),text('The model’s target use',1110,576,27,muted,400,2)]},
 {header:'MEMORY BUDGET',panels:P[1],copy:[
 text('Active parameters do not set the memory budget.',80,220,38,ink,700),
 text('24B total',110,363,32,blue,700,0,'total-weights'),text('14.5 GB',110,459,76,blue,700,0),text('Q4_K_M weight file',110,523,30,muted,400,0),
 text('Runtime',790,363,32,green,700,1),text('KV cache',790,434,31,ink,700,1),text('+ buffers',790,482,31,ink,700,1),
 text('Headroom',1210,363,32,red,700,2),text('Other apps',1210,434,27,muted,400,2),text('+ operating',1210,475,27,muted,400,2),text('system',1210,516,27,muted,400,2),
 text('Published file size, not a measured RAM requirement.',80,645,30,ink,700),text('Memory also depends on context, runtime and concurrency.',80,693,27)]},
 {header:'SPEED: READ THE METRIC',panels:P[2],copy:[
 text('Decoding speed ≠ time to finish a task.',80,220,40,ink,700),
 text('M5 Max',110,356,35,blue,700,0),text('On-device decoding',110,405,27,muted,400,0),text('Tokens per second',110,551,27,blue,700,0),
 text('B300 GPU',610,356,35,green,700,1),text('Many concurrent requests',610,405,25,muted,400,1),text('Aggregate throughput',610,551,27,green,700,1),
 text('Your task',1110,356,35,red,700,2),text('Planning + tool calls',1110,405,27,muted,400,2),text('+ retries + final output',1110,446,26,muted,400,2),text('End-to-end time',1110,551,27,red,700,2),
 text('Liquid’s reported results use different workloads and hardware.',80,651,29),text('Stream diagrams illustrate metrics; their speed is not benchmark data.',80,697,25)]},
 {header:'MIXED VENDOR RESULTS',panels:P[3],copy:[
 text('Liquid’s comparison with Qwen3.6-35B-A3B',80,208,36,ink,700),
 text('AutomationBench',110,332,32,blue,700,0),text('27.69  vs  8.72',815,332,33,ink,700,0),text('Higher',1345,332,29,blue,700,0),
 text('LiveClaw',110,457,32,green,700,1),text('48.09  vs  38.19',815,457,33,ink,700,1),text('Higher',1345,457,29,green,700,1),
 text('SWE-Bench Verified',110,582,32,red,700,2),text('51.00  vs  66.20',815,582,33,ink,700,2),text('Lower',1345,582,29,red,700,2),
 text('Scores shown as LFM / Qwen; SWE-Bench uses OpenCode.',80,672,27),text('Vendor measurements. Independent confirmation is still needed.',80,714,27,ink,700)]},
 {header:'THE AGENT SYSTEM',panels:P[4],copy:[
 text('The harness connects the model to real actions.',80,220,39,ink,700),
 text('Local model',110,376,34,blue,700,0),text('Reasoning + output',110,430,28,muted,400,0),text('Runs on your hardware',110,477,26,muted,400,0),
 text('Agent harness',620,376,34,green,700,1),text('Tools + permissions',620,430,27,muted,400,1),text('Recovery + audit trail',620,477,26,muted,400,1),
 text('Tool destination',1130,376,32,red,700,2),text('Local files or apps',1130,430,27,muted,400,2),text('External search / APIs',1130,477,26,muted,400,2),
 text('External tools can send data off the device.',80,641,33,ink,700),text('Local inference alone does not determine where tool data goes.',80,688,27)]},
 {header:'MAKE THE DEPLOYMENT CHOICE',panels:P[5],copy:[
 text('Choose the complete system for your workload.',80,198,38,ink,700),
 text('Memory',170,320,33,blue,700,0),text('Weights + runtime + headroom',600,320,31,ink,400,0),
 text('Task fit',170,450,33,green,700,1),text('Verified results on your actual tasks',600,450,31,ink,400,1),
 text('Acceptable delay',170,580,33,red,700,2),text('Measure the whole agent workflow',600,580,31,ink,400,2),
 text('Review the LFM license before commercial deployment.',80,674,30,ink,700),text('Token speed matters when the whole system delivers the right result.',80,719,27)]},
];
export const transitionBefore=.40,transitionAfter=1.00;
function stateAt(t:number){
 for(let i=1;i<timing.scenes.length;i++){const boundary=timing.scenes[i];if(t>=boundary-transitionBefore&&t<boundary+transitionAfter)return {from:i-1,to:i,u:(t-boundary+transitionBefore)/(transitionBefore+transitionAfter)};}
 let index=0;for(let i=1;i<timing.scenes.length;i++)if(t>=timing.scenes[i])index=i;
 return {from:index,to:index,u:1};
}
const Text=({item,opacity=1,dx=0,dy=0}:{item:Copy;opacity?:number;dx?:number;dy?:number})=><text x={item.x+dx} y={item.y+dy} fontSize={item.size} fill={item.color||muted} fontWeight={item.weight||400} opacity={opacity}>{item.text}</text>;
export function Frame({frame}:{frame:number}){
 const t=frame/timing.fps,{from,to,u}=stateAt(t),moving=from!==to,q=ease(u),a=scenes[from],b=scenes[to];
 const morph=a.panels.map((p,i)=>{const v=b.panels[i];let x=mix(p.x,v.x,q),y=mix(p.y,v.y,q),w=mix(p.w,v.w,q),h=mix(p.h,v.h,q);
  // Cards flatten into separate rows before growing horizontally. The return
  // journey narrows the rows first, then places them along the tool path.
  if(moving&&(to===3||to===5)){const fold=ease(u/.47),spread=ease((u-.47)/.53);y=mix(p.y,v.y,fold);h=mix(p.h,v.h,fold);x=mix(p.x,v.x,spread);w=mix(p.w,v.w,spread);}
  if(moving&&to===4){const fold=ease(u/.47),place=ease((u-.47)/.53);x=mix(p.x,v.x,fold);w=mix(p.w,v.w,fold);y=mix(p.y,v.y,place);h=mix(p.h,v.h,place);}
  return {x,y,w,h,color:colorMix(p.color,v.color,q)};});
 // Numeric benchmark copy exits fully before harness labels enter. All other
 // boundaries have a brief overlap, held at readable sizes inside their panels.
 const foldTransition=moving&&to>=3;
 const oldOpacity=moving?1-ease((u-(foldTransition?.08:from===0?.12:.27))/(foldTransition?.18:from===0?.22:.28)):0;
 const newOpacity=moving?ease((u-(foldTransition?.78:.50))/(foldTransition?.20:.29)):1;
 const common=new Set(a.copy.filter(x=>x.shared&&b.copy.some(y=>y.shared===x.shared&&y.text===x.text)).map(x=>x.shared!));
 const headerIn=ease((t-3.60)/.5),bodyIn=ease((t-3.68)/.6),out=ease((t-(timing.outro-.16))/.46),headerOut=ease((t-(timing.outro-.16))/.16);
 const drawCopy=(scene:Scene,alpha:number,isOld=false)=>scene.copy.filter(item=>!common.has(item.shared||'')).map((item,i)=>{const p=item.panel;return <Text key={i} item={item} opacity={alpha} dx={p===undefined||(isOld&&foldTransition)?0:morph[p].x-scene.panels[p].x} dy={p===undefined||(isOld&&foldTransition)?0:morph[p].y-scene.panels[p].y}/>;});
 const layerAlpha=(n:number)=>moving?(from===n?oldOpacity:to===n?newOpacity:0):(to===n?1:0);
 return <svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900" role="img" aria-label={`LFM2.5 deployment: ${b.header}`}>
 <defs><linearGradient id="theme"><stop offset="0%" stopColor="#0062cc"/><stop offset="50%" stopColor="#208235"/><stop offset="100%" stopColor="#d92820"/></linearGradient>
 <clipPath id="headerClip"><rect x="140" y="32" width={1364*headerIn*(1-headerOut)} height="82"/></clipPath><clipPath id="bodyClip"><rect x="76" y="135" width={1448*bodyIn*(1-out)} height="665"/></clipPath>
 <linearGradient id="progress"><stop offset="0%" stopColor="#007aff"/><stop offset="50%" stopColor="#34c759"/><stop offset="100%" stopColor="#ff3b30"/></linearGradient><clipPath id="progressClip"><rect x="0" y="892.5" width={1600*clamp(frame/(timing.durationInFrames-1))} height="7.5"/></clipPath></defs>
 <g fontFamily="DejaVu Sans, sans-serif"><g clipPath="url(#headerClip)" transform={`translate(${48*(1-headerIn)-24*headerOut} 0)`}>
 {moving&&<text x={140-20*ease(u)} y="91" fontSize="36" fontWeight="700" fill="url(#theme)" opacity={1-ease((u-.28)/.20)}>{a.header}</text>}
 <text x={140+(moving?20*(1-ease((u-.5)/.5)):0)} y="91" fontSize="36" fontWeight="700" fill="url(#theme)" opacity={moving?ease((u-.5)/.2):1}>{b.header}</text></g>
 <g clipPath="url(#bodyClip)" transform={`translate(${64*(1-bodyIn)-48*out} ${-12*out})`}>
 {morph.map((p,i)=><g key={i} data-shared-panel={i}><rect x={p.x} y={p.y} width={p.w} height={p.h} rx={Math.min(24,p.h/2)} fill="white" stroke="#dce4ef" strokeWidth="2"/><rect x={p.x} y={p.y+24} width="5" height={p.h-48} rx="2.5" fill={p.color}/></g>)}
 <g opacity={layerAlpha(2)}>{[0,1].map(i=>{const p=morph[i],rows=i===0?1:3;return Array.from({length:rows},(_,r)=>{const y=p.y+165+r*23;return <g key={`${i}-${r}`}><path d={`M${p.x+30} ${y}h355`} stroke="#dce4ef" strokeWidth="5" strokeLinecap="round"/>{[0,1,2,3].map(j=><circle key={j} cx={p.x+35+((t*65+j*88+r*32)%340)} cy={y} r="6" fill={p.color}/>)}</g>})})}</g>
 <g opacity={layerAlpha(4)}>{[0,1].map(i=><path key={i} d={`M${morph[i].x+morph[i].w+10} ${morph[i].y+118}H${morph[i+1].x-12}m-11 -7l11 7 -11 7`} fill="none" stroke={i?red:green} strokeWidth="3" strokeLinecap="round"/>)}</g>
 <g opacity={layerAlpha(5)}>{morph.map((p,i)=><g key={i}><rect x={p.x+29} y={p.y+34} width="34" height="34" rx="8" fill={p.color} opacity=".10"/><path d={`M${p.x+37} ${p.y+51}l7 7 13 -15`} fill="none" stroke={p.color} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"/></g>)}</g>
 {moving&&drawCopy(a,oldOpacity,true)}{drawCopy(b,newOpacity)}
 {[...common].map(id=>{const s=a.copy.find(x=>x.shared===id)!,v=b.copy.find(x=>x.shared===id)!;return <Text key={id} item={{...s,x:mix(s.x,v.x,q),y:mix(s.y,v.y,q),size:mix(s.size,v.size,q),color:colorMix(s.color||muted,v.color||muted,q)}}/>})}
 </g></g><rect x="0" y="892.5" width="1600" height="7.5" fill="#e2e8f0"/><rect x="0" y="892.5" width="1600" height="7.5" fill="url(#progress)" clipPath="url(#progressClip)"/>
 </svg>;
}
export const Video=()=>{const frame=useCurrentFrame();return <AbsoluteFill style={{background:'#f7f9fc'}}><BrandCanvas time={frame/timing.fps}/><div style={{position:'absolute',width:1600,height:900,transform:'scale(.8)',transformOrigin:'top left'}}><Frame frame={frame}/></div><Audio src={staticFile('review-audio.wav')}/></AbsoluteFill>};
