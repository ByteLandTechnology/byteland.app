"""Validate the actual encoded Liquid movie; emit frames for human/visual inspection."""
from pathlib import Path
from PIL import Image,ImageDraw
import json,subprocess,re,hashlib,shutil
P=Path(__file__).resolve().parents[1];D=P.parent/'deliverables/video';T=json.loads((P/'src/timing.json').read_text());movie=D/'lfm25-local-agents-v1.mp4'
probe=subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','format=duration,size:stream=codec_name,width,height,avg_frame_rate,nb_read_frames,pix_fmt,sample_rate,channels','-of','json',str(movie)],text=True)
(P/'qa/final-probe.json').write_text(probe);j=json.loads(probe)
assert j['streams'][0]['nb_read_frames']==str(T['durationInFrames']) and float(j['format']['duration'])>=60
assert (j['streams'][0]['width'],j['streams'][0]['height'],j['streams'][0]['avg_frame_rate'])==(1280,720,'60/1')
subprocess.run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-'],check=True)
log=subprocess.run(['ffmpeg','-hide_banner','-i',str(movie),'-af','ebur128=peak=true','-f','null','-'],check=True,capture_output=True,text=True).stderr;(P/'qa/final-audio-loudness.log').write_text(log)
summary=log[log.rfind('Summary:'):];audio={'integrated_lufs':float(re.search(r'I:\s+(-?[\d.]+) LUFS',summary).group(1)),'loudness_range_lu':float(re.search(r'LRA:\s+(-?[\d.]+) LU',summary).group(1)),'true_peak_dbtp':float(re.search(r'Peak:\s+(-?[\d.]+) dBFS',summary).group(1))};(P/'qa/final-audio-levels.json').write_text(json.dumps(audio,indent=2)+'\n')
scenes=[480,1080,1920,2580,3420,4140];bookends=[0,155,214,240,4740,4800,4827];offsets=[-.5,-.1,0,.25,.55,1.0];boundaries=T['scenes'][1:]
keys=sorted(set(scenes+bookends+[round((b+d)*T['fps']) for b in boundaries for d in offsets]))
selector='+'.join('eq(n\\,{})'.format(f) for f in keys)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(movie),'-vf','select='+selector,'-fps_mode','vfr','-frames:v',str(len(keys)),str(P/'qa/sample-%03d.png')],check=True)
for index,f in enumerate(keys,1):(P/f'qa/sample-{index:03}.png').replace(P/f'qa/encoded-{f:04}.png')
shutil.copy2(P/'qa/encoded-0480.png',D.parent/'video-frame-check.png')
for boundary in boundaries:
 sheet=Image.new('RGB',(1280,1080),'white');draw=ImageDraw.Draw(sheet)
 for i,d in enumerate(offsets):
  f=round((boundary+d)*T['fps']);im=Image.open(P/f'qa/encoded-{f:04}.png').convert('RGB').resize((640,360));sheet.paste(im,((i%2)*640,(i//2)*360));draw.text(((i%2)*640+520,(i//2)*360+335),f'{f/T["fps"]:.2f} seconds',fill='#172033')
 sheet.save(D/f'transition-{boundary:02}-encoded.jpg',quality=94)
checks={'revision':'liquid-v1','render_method':'Native React SVG + EGL + FFmpeg','movie_sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'scene_frame_numbers':scenes,'bookend_frame_numbers':bookends,'boundary_seconds':boundaries,'offsets_seconds':offsets,'encoded_sample_frame_numbers':keys,'frame_extraction_complete':True,'visual_inspection_pending':True}
(P/'qa/transition-validation.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
