"""Local, offline Liquid narration synthesis; no post-generation time stretching."""
import os
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'tts'
MODEL_DIR = Path(os.environ.get('KOKORO_MODEL_DIR', str(ROOT / 'tts/models')))
BASE.mkdir(exist_ok=True)
os.environ['ORT_DISABLE_TELEMETRY'] = '1'
os.environ['XDG_CACHE_HOME'] = str(BASE / 'cache')
import dataclasses, hashlib, importlib.metadata, json, re, wave
import numpy as np
import onnxruntime as ort
from kokoro_onnx import Kokoro

OUT = ROOT / 'audio/generated-sentences'
OUT.mkdir(parents=True,exist_ok=True)
SCRIPT = ROOT / 'audio/narration-script.json'
SR, TOTAL_SAMPLES, GAP_SAMPLES = 24000, 1931200, 4320
MAX_SPEED = 1.25
NORMALIZATIONS = {'M-five':'M five', 'B-three-hundred':'B three hundred', 'Q-four':'Q four', 'Qwen':'Kwen'}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, audio):
    assert np.isfinite(audio).all() and float(np.max(np.abs(audio))) < 1.0
    pcm = np.rint(audio * 32767).astype('<i2')
    with wave.open(str(path), 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(SR)
        wav.writeframes(pcm.tobytes())
    return {'sha256': digest(path), 'samples': len(pcm), 'clippedSamples': int(np.count_nonzero((pcm == -32768) | (pcm == 32767)))}

def normalize(text):
    for a, b in NORMALIZATIONS.items():
        text = text.replace(a, b)
    return text

ort.disable_telemetry_events()
options = ort.SessionOptions()
options.intra_op_num_threads, options.inter_op_num_threads = 4, 1
options.log_severity_level = 3
session = ort.InferenceSession(str(MODEL_DIR / 'kokoro-v1.0.fp16.onnx'), sess_options=options, providers=['CPUExecutionProvider'])
kokoro = Kokoro.from_session(session, str(MODEL_DIR / 'voices-v1.0.bin'))
assert kokoro.get_voice_style('af_heart').size > 0

def generate(text, speed):
    phon = kokoro.tokenizer.phonemize(normalize(text), 'en-us')
    audio, rate, timings = kokoro.create_timed(phon, voice='af_heart', lang='en-us', speed=speed, is_phonemes=True, sentence_pause=0.08, clause_pause=0.04)
    assert rate == SR and np.isfinite(audio).all() and float(np.max(np.abs(audio))) > 0.02
    return audio, phon, timings

script_bytes = SCRIPT.read_bytes()
data = json.loads(script_bytes)
assert data['revision'] == 'liquid-v1'
assert [x['id'] for x in data['segments']] == ['launch', 'weights', 'throughput', 'evidence', 'harness', 'selection']
report = {
    'revision': 'liquid-v1', 'engine': 'kokoro-onnx ' + importlib.metadata.version('kokoro-onnx'),
    'runtime': 'onnxruntime ' + ort.__version__ + ' CPUExecutionProvider',
    'model': 'Kokoro v1.0 fp16', 'voice': 'af_heart', 'sampleRate': SR,
    'channels': 1, 'bitDepth': 16, 'scriptAltered': False,
    'scriptSha256': hashlib.sha256(script_bytes).hexdigest(),
    'modelSha256': digest(MODEL_DIR / 'kokoro-v1.0.fp16.onnx'),
    'voiceBankSha256': digest(MODEL_DIR / 'voices-v1.0.bin'),
    'generatorSha256': digest(Path(__file__)),
    'pronunciationNormalizations': NORMALIZATIONS, 'sentenceGap': GAP_SAMPLES / SR,
    'auditoryReview': False, 'asrReview': False, 'postGenerationTimeStretch': False,
    'timingMethod': 'Each sentence synthesized independently; full-timeline endpoints and durations measured from sample counts. Bounds include any model-generated edge silence.',
    'modelProvidesPhonemeTimings': kokoro.has_timings,
    'durationFraction': '4828/60', 'sampleCount': TOTAL_SAMPLES, 'segments': []
}
full = np.zeros(TOTAL_SAMPLES, dtype=np.float32)
arrays = {}
flat = []
for seg in data['segments']:
    texts = [s.strip() for s in re.findall(r'[^.!?]+[.!?]?', seg['text']) if s.strip()]
    assert ' '.join(texts) == seg['text']
    max_samples = round((seg['end'] - seg['start'] - .1) * SR)
    desired_samples = max_samples - GAP_SAMPLES * (len(texts) - 1)
    speed = 1.0
    clips = [generate(t, speed) for t in texts]
    samples = sum(len(x[0]) for x in clips)
    attempts = [{'speed': speed, 'speechSamples': samples}]
    print('INITIAL', seg['id'], 'speech', round(samples/SR,3), 'target', round(desired_samples/SR,3), 'rate_ratio', round(samples/desired_samples,3), flush=True)
    # Fit using the model's duration/speed input only; do not stretch finished audio.
    for attempt in range(4):
        ratio = samples / desired_samples
        if samples <= desired_samples and (ratio >= .95 or attempt > 0):
            break
        new_speed = max(.85, speed * ratio * (1.013 if samples > desired_samples else 1.0))
        if new_speed > MAX_SPEED:
            problem = {'segment': seg, 'requiredSpeedEstimate': new_speed, 'maximumUnreviewedSpeed': MAX_SPEED, 'message': 'Pause for editorial guidance; script has not been changed.', 'attempts': attempts}
            (OUT / 'RATE-BLOCKER.json').write_text(json.dumps(problem, indent=2))
            raise RuntimeError(json.dumps(problem))
        speed = new_speed
        clips = [generate(t, speed) for t in texts]
        samples = sum(len(x[0]) for x in clips)
        attempts.append({'speed': speed, 'speechSamples': samples})
    used_samples = samples + GAP_SAMPLES * (len(texts) - 1)
    if used_samples > max_samples:
        raise RuntimeError(f'Segment does not fit: {seg["id"]}: {used_samples} > {max_samples}')
    cursor = round(seg['start'] * SR)
    srpt = {**seg, 'speed': speed, 'speechAndPausesDuration': used_samples/SR, 'speechAndPausesSamples': used_samples, 'attempts': attempts, 'sentences': []}
    parts = []
    for i, (text, (audio, phon, timings)) in enumerate(zip(texts, clips), 1):
        fade = min(96, len(audio)//2)
        audio = audio.copy()
        audio[:fade] *= np.linspace(0,1,fade)
        audio[-fade:] *= np.linspace(1,0,fade)
        end_sample = cursor + len(audio)
        assert end_sample <= round(seg['end']*SR)
        name = f'{seg["id"]}-{i:02d}.wav'
        arrays[name] = audio
        full[cursor:end_sample] += audio
        phon_timings = [dataclasses.asdict(x) if dataclasses.is_dataclass(x) else str(x) for x in timings]
        sentence = {'segmentId': seg['id'], 'sentenceIndex': i, 'text': text, 'spokenText': normalize(text), 'start': cursor/SR, 'end': end_sample/SR, 'startSample': cursor, 'endSample': end_sample, 'duration': len(audio)/SR, 'samples': len(audio), 'wav': str((OUT/name).relative_to(ROOT)), 'phonemes': phon, 'phonemeTimingsRelativeToClip': phon_timings}
        srpt['sentences'].append(sentence)
        flat.append({k:v for k,v in sentence.items() if k not in ('phonemes','phonemeTimingsRelativeToClip')})
        parts.append(audio)
        cursor = end_sample
        if i < len(clips):
            parts.append(np.zeros(GAP_SAMPLES,dtype=np.float32))
            cursor += GAP_SAMPLES
    name = f'{seg["id"]}.wav'
    arrays[name] = np.concatenate(parts)
    srpt['wav'] = str((OUT/name).relative_to(ROOT))
    srpt['actualEnd'] = cursor/SR
    srpt['tailRoom'] = seg['end'] - cursor/SR
    report['segments'].append(srpt)
    (OUT/'narration-timing.partial.json').write_text(json.dumps(report, indent=2))
    print('DONE', seg['id'], 'speed', round(speed,4), 'used', round(used_samples/SR,3), 'end', cursor/SR, flush=True)

assert SCRIPT.read_bytes() == script_bytes, 'Script changed during generation'
peak = float(np.max(np.abs(full)))
gain = min(10**(-2/20)/peak, 2.8)
full *= gain
report['gainDb'] = float(20*np.log10(gain))
report['gainAppliedToAllClips'] = True
report['duration'] = len(full)/SR
report['peakDbfs'] = float(20*np.log10(np.max(np.abs(full))))
report['rmsDbfs'] = float(20*np.log10(np.sqrt(np.mean(full*full))))
report['speechAndPausesDuration'] = sum(x['speechAndPausesDuration'] for x in report['segments'])
artifacts = {}
for name, audio in arrays.items():
    artifacts[name] = write(OUT/name, audio*gain)
artifacts['narration.wav'] = write(OUT/'narration.wav', full)
report['wav'] = str((OUT/'narration.wav').relative_to(ROOT))
report['sha256'] = artifacts['narration.wav']['sha256']
report['artifacts'] = artifacts
(OUT/'narration-timing.json').write_text(json.dumps(report, indent=2))
(OUT/'sentence-timing.json').write_text(json.dumps(flat, indent=2))
print('FINAL',json.dumps({k:v for k,v in report.items() if k not in ('segments','artifacts')}),flush=True)

# Portable-package delivery copies after all validated synthesis steps succeed.
import shutil
for name in ['narration.wav','narration-timing.json','sentence-timing.json']:
    shutil.copy2(OUT/name,ROOT/'audio'/name)
