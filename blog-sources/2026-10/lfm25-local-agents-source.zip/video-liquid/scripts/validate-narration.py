"""Objective narration checks; does not claim playback or perceptual review."""
from pathlib import Path
import json,wave,hashlib,subprocess,re
import numpy as np
P=Path(__file__).resolve().parents[1];file=P/'audio/narration.wav';timing=json.loads((P/'audio/narration-timing.json').read_text());movie=json.loads((P/'src/timing.json').read_text())
with wave.open(str(file),'rb') as f:
 params=(f.getframerate(),f.getnchannels(),f.getsampwidth(),f.getnframes());pcm=f.readframes(f.getnframes())
assert params==(24000,1,2,1931200);data=np.frombuffer(pcm,dtype='<i2');assert not np.any((data==-32768)|(data==32767))
mask=np.zeros(len(data),dtype=bool);count=0
for s in timing['segments']:
 assert s['actualEnd']<=s['end'] and s['speed']<=1.25
 for t in s['sentences']:
  with wave.open(str(P / t['wav']),'rb') as f:a=f.readframes(f.getnframes())
  assert a==pcm[t['startSample']*2:t['endSample']*2]
  mask[t['startSample']:t['endSample']]=True;count+=1
assert count==17 and not np.any(data[~mask])
decoded=subprocess.check_output(['ffmpeg','-v','error','-i',str(file),'-f','s16le','-']);assert decoded==pcm
log=subprocess.run(['ffmpeg','-hide_banner','-i',str(file),'-af','ebur128=peak=true','-f','null','-'],check=True,capture_output=True,text=True).stderr
(P/'audio/narration-loudness-analysis.txt').write_text(log.replace(str(P.resolve())+'/', ''))
summary=log[log.rfind('Summary:'):];levels={'integrated_lufs':float(re.search(r'I:\s+(-?[\d.]+) LUFS',summary).group(1)),'loudness_range_lu':float(re.search(r'LRA:\s+(-?[\d.]+) LU',summary).group(1)),'true_peak_dbtp':float(re.search(r'Peak:\s+(-?[\d.]+) dBFS',summary).group(1))}
report={'revision':'liquid-v1','sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'samples':len(data),'duration_seconds':len(data)/24000,'sentence_count':count,'all_segments_fit':True,'clip_and_timeline_pcm_identical':True,'full_decode_passed':True,'clipped_samples':0,'outside_speech_silent':True,'auditory_review':False,'asr_review':False,**levels}
(P/'audio/narration-validation.json').write_text(json.dumps(report,indent=2)+'\n');(P/'audio/narration-sha256.txt').write_text(report['sha256']+'  narration.wav\n');print(json.dumps(report,indent=2))
