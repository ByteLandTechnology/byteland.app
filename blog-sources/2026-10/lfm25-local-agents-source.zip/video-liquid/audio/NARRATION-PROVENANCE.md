# Liquid local-agents narration provenance

Generated locally on October 15, 2026 from the exact supplied six-part script.
This is synthetic speech with the packaged Kokoro af_heart American English stock
voice. No personal voice reference, impersonation, paid API, credentials, new package
installation, model download or browser access was used.

## Runtime and rights

The existing Kokoro v1.0 fp16 ONNX model and voice bank were reused read-only. The
model card states Apache-2.0 licensing; the wrapper is MIT, ONNX Runtime is MIT, and
phonemizer/eSpeak components have their own GPL terms. Exact notices, stock voice
documentation, and the previously verified 17-wheel package manifest are retained
under narration-licenses. The model's training-data statements are publisher claims,
not an independent training-data rights audit.

- Model and voice source: https://huggingface.co/hexgrad/Kokoro-82M
- Voice documentation: https://huggingface.co/hexgrad/Kokoro-82M/blob/main/VOICES.md
- ONNX export: https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.1
- Wrapper: https://pypi.org/project/kokoro-onnx/0.6.1/
- Runtime: kokoro-onnx 0.6.1, onnxruntime 1.22.1 CPUExecutionProvider, Python 3.12.14.
  Telemetry was disabled through the runtime API and environment setting.

Model SHA-256: f3a290d384fbb27966d462905c71a46cef9e5fd00516b40df32a0b4afe77ac96

Voice bank SHA-256: bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d

Narration SHA-256: 308d88ac3f456be6e67b0cdf9db47cca1fd1436d7dedf0a2853bdc13f2ec5dd7

## Generation

The exact 158-word supplied text is in narration-script.txt and narration-script.json.
Seventeen sentences were generated separately, with 180 ms sentence gaps and 4 ms
edge fades. Only pronunciation spelling was normalized: M-five → M five,
B-three-hundred → B three hundred, Q-four → Q four, Qwen → Kwen. Meaning and script
wording were not edited.

Neural duration settings range from 0.855937 to 1.000000. No post-generation time stretching
or pitch shifting was used. One uniform gain was applied to the final timeline and
individual clips. The exact generated sample counts establish sentence boundaries.
No ASR or human-listened alignment is claimed.

The full-timeline stem has exactly 1,931,200 samples: 80.4666667 seconds, 24 kHz mono
16-bit PCM. Speech begins at 4.15 seconds and ends at 76.516 seconds. Intro and outro
are silent in this stem. Effects are mixed separately.

The complete timeline decoded successfully and matched PCM bytes. Sentence clips
match corresponding timeline samples. All six windows fit, with zero clipped samples.
Raw stem: −21.6 LUFS integrated, 2.5 LU loudness range, −2.0 dBTP. See
narration-validation.json.

These are objective technical checks. No auditory listening, independent recognition,
pronunciation evaluation or perceptual-quality review is claimed.

## Reproduction

The synthesis logic is in scripts/generate-narration.py. Metadata paths are package-relative, and the cache location is portable; these path-only adaptations were not used to regenerate the included narration. Set KOKORO_MODEL_DIR to
the directory containing the two verified model files; use the isolated pinned
narration environment from narration-requirements.txt. Generated sentence clips are
local intermediate files, excluded from the deliverable source archive. Timing JSON
retains measured clip provenance; the model weights and environments are excluded.
