# Transformers type-preservation regression lab

This is a CPU-only comparison of Transformers 5.20.1 and 5.20.2. It does not test
GPU transfer, intelligence, trained-model quality, throughput, or distributed operation.

## Setup and run

Tested with CPython 3.12.14 on Linux x86_64. Setup needs internet access to official
package indexes. Execution uses only CPU and locally initialized random model weights.

```sh
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install torch==2.14.1+cpu --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
bash fetch-runtime.sh  # one-time public source fetch, then verify SHA-256
bash run.sh
```

The source archives fetched by fetch-runtime.sh are exact src/ trees from upstream release commits, not
locally patched approximations. provenance.json records commits. runtime-archives.sha256 records deterministic archive hashes.
run.sh extracts them into separate folders, sets PYTHONPATH and executes each in a
separate process. Dependencies are shared. HF_HUB_OFFLINE and telemetry opt-out are set.
No .from_pretrained() call or model service is used.

probe.py is the ByteLand experiment harness. The forced-path checks temporarily patch
PreTrainedModel.device to cpu:0 while tensors stay on CPU. This chooses the affected
conditional branch without testing a physical device transfer. Model sizes: BART 8,768
parameters, LLaVA 8,352. A fixed seed and greedy generation produce shape assertions,
not semantic output claims.

upstream_test.py extracts and runs the unmodified test_generation_device_placement_respect_type
method from the bundled upstream test file. It supplies the method's normal imported
symbols but does not import the complete test suite. Expected: old fails the first
ModelOutput type assertion; new passes. This is one targeted method, not full CI.

The defaultdict case deliberately asks whether an unsupported constructor shape is
preserved. It fails in both versions, in different ways. Do not treat it as a documented
input support guarantee or combine it with fixed cases into a general quality score.

verify_results.py verifies the observed differences against recorded results. A clean
copy of this bundle was extracted and run with the existing pinned dependency environment;
it reproduced both versions. A second fresh package installation was not performed.

## Sources and rights

- https://github.com/huggingface/transformers/releases/tag/v5.20.2
- https://github.com/huggingface/transformers/pull/49731
- https://github.com/huggingface/transformers/issues/49699

Upstream runtime and test file: Apache-2.0, retained in TRANSFORMERS-LICENSE and archives.
The ByteLand harness is supplied under MIT; see LICENSE. No credentials or trained
model weights are included. Dependency licenses remain their respective authors'.

Compact distribution: upstream runtime archives are omitted to fit attachment limits. fetch-runtime.sh obtains them from the official repository, checks exact commit IDs, and verifies deterministic archive checksums. The source fetch requires internet; run.sh itself does not. Separate runtime archives can also be copied beside run.sh.
