import json
from pathlib import Path
p=Path(__file__).parent
for v in ['5.20.1','5.20.2']:
 d=json.loads((p/f'reproduced-{v}.json').read_text());expected=json.loads((p/f'results-{v}.json').read_text())
 assert d['cases']==expected['cases'],f'Results differ for {v}'
 u=json.loads((p/f'upstream-reproduced-{v}.json').read_text());assert u['passed']==(v=='5.20.2')
print('Both version probes and upstream pass/fail outcomes match the recorded results.')
