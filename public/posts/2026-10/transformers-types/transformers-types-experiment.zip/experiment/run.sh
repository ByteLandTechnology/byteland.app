#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON=${PYTHON:-python3}
export HF_HUB_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1 OMP_NUM_THREADS=1
for version in 5.20.1 5.20.2; do
 mkdir -p "runtime-$version"
 tar -xzf "runtime-$version.tar.gz" -C "runtime-$version"
 PYTHONPATH="$PWD/runtime-$version/src" "$PYTHON" probe.py > "reproduced-$version.json"
 PYTHONPATH="$PWD/runtime-$version/src" "$PYTHON" upstream_test.py > "upstream-reproduced-$version.json"
done
"$PYTHON" verify_results.py
