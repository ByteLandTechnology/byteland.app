"""ByteLand CPU regression probe; no downloaded weights or service calls."""
import json, platform, traceback, sys
from collections import OrderedDict, defaultdict
from unittest.mock import patch
import torch
import transformers
from transformers import BartConfig, BartForConditionalGeneration, CLIPVisionConfig, LlamaConfig, LlavaConfig, LlavaForConditionalGeneration, PreTrainedModel
from transformers.modeling_outputs import BaseModelOutput
from transformers.pytorch_utils import move_to_device

torch.set_num_threads(1)
torch.manual_seed(0)
results=[]
def check(name,fn,expected):
    try:
        actual=fn(); ok=actual==expected
    except Exception as e:
        actual={'error':type(e).__name__,'message':str(e)}; ok=actual==expected
    results.append(dict(name=name,expected=expected,actual=actual,passed=ok))

def output(): return BaseModelOutput(last_hidden_state=torch.zeros(1,2,4),hidden_states=(torch.zeros(2,4),torch.ones(2,4)))
check('ModelOutput type',lambda:type(move_to_device(output(),torch.device('cpu'))).__name__,'BaseModelOutput')
check('ModelOutput attribute',lambda:list(move_to_device(output(),torch.device('cpu')).last_hidden_state.shape),[1,2,4])
check('Nested mapping type',lambda:type(move_to_device({'image':output()},torch.device('cpu'))['image']).__name__,'BaseModelOutput')
check('OrderedDict type',lambda:type(move_to_device(OrderedDict(x=torch.zeros(1)),torch.device('cpu'))).__name__,'OrderedDict')
check('Ordinary dict control',lambda:type(move_to_device({'x':torch.zeros(1)},torch.device('cpu'))).__name__,'dict')
check('Tuple and tensor control',lambda:(lambda x:[type(x).__name__,x[0].tolist()])(move_to_device((torch.ones(2),),torch.device('cpu'))),['tuple',[1.,1.]])
# The patch is not a generic reconstruction protocol for all Python mappings.
check('defaultdict limitation',lambda:type(move_to_device(defaultdict(list,x=torch.zeros(1)),torch.device('cpu'))).__name__,'defaultdict')

bart=BartForConditionalGeneration(BartConfig(vocab_size=64,d_model=16,encoder_layers=1,decoder_layers=1,encoder_attention_heads=2,decoder_attention_heads=2,encoder_ffn_dim=32,decoder_ffn_dim=32,max_position_embeddings=64)).eval()
llava=LlavaForConditionalGeneration(LlavaConfig(vision_config=CLIPVisionConfig(hidden_size=16,intermediate_size=32,num_hidden_layers=1,num_attention_heads=2,image_size=8,patch_size=4,projection_dim=16),text_config=LlamaConfig(vocab_size=64,hidden_size=16,intermediate_size=32,num_hidden_layers=1,num_attention_heads=2,num_key_value_heads=2,max_position_embeddings=64,pad_token_id=0),image_token_index=63,vision_feature_layer=-1,vision_feature_select_strategy='full')).eval()
ids=torch.tensor([[0,5,6,7,2]]); image_ids=torch.tensor([[1]+[63]*5+[5,6]]); pixels=torch.randn(1,3,8,8)
def run_bart():
    with torch.no_grad():return list(bart.generate(ids,max_new_tokens=3,do_sample=False).shape)
def run_llava():
    with torch.no_grad():return list(llava.generate(input_ids=image_ids,pixel_values=pixels,max_new_tokens=3,do_sample=False).shape)
check('BART normal CPU control',run_bart,[1,4]);check('LLaVA normal CPU control',run_llava,[1,11])
with patch.object(PreTrainedModel,'device',property(lambda self:torch.device('cpu',0))):
    check('BART forced transfer branch',run_bart,[1,4]);check('LLaVA forced transfer branch',run_llava,[1,11])
print(json.dumps(dict(python=platform.python_version(),torch=torch.__version__,transformers=transformers.__version__,source=transformers.__file__,device='CPU; property patched only for forced-branch checks',seed=0,model_parameters={'bart':sum(p.numel() for p in bart.parameters()),'llava':sum(p.numel() for p in llava.parameters())},cases=results),indent=2))
