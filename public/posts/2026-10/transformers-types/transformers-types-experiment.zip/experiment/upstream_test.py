"""Run the unmodified targeted upstream test method against either source runtime."""
import ast, json, pathlib, unittest
from unittest.mock import patch
from contextlib import contextmanager
import torch, transformers
from transformers import LlamaForCausalLM, LlamaConfig, PreTrainedModel
p=pathlib.Path(__file__).parent/'upstream-test_utils.py'
tree=ast.parse(p.read_text());node=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='test_generation_device_placement_respect_type')
module=ast.Module(body=[node],type_ignores=[]);exec(compile(ast.fix_missing_locations(module),str(p),'exec'))
torch.set_num_threads(1)
try:
 test_generation_device_placement_respect_type(unittest.TestCase()); result={'passed':True}
except Exception as e:result={'passed':False,'error':type(e).__name__,'message':str(e)}
print(json.dumps({'version':transformers.__version__,'case':node.name,**result},indent=2))
