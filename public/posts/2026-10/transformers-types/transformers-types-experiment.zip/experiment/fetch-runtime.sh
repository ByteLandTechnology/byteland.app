#!/usr/bin/env bash
# Fetch public source only. No credentials, model weights, or service calls.
set -euo pipefail
cd "$(dirname "$0")"
for version in 5.20.1 5.20.2; do
 if [[ "$version" == 5.20.1 ]]; then expected=0ea877911a11499053df677befd4b35b172ff502; else expected=18329f1065382e54db698e242cf98bd3f3e5a766; fi
 checkout=$(mktemp -d "./source-$version-XXXXXX")
 git clone --depth=1 --branch "v$version" https://github.com/huggingface/transformers.git "$checkout"
 actual=$(git -C "$checkout" rev-parse HEAD)
 [[ "$actual" == "$expected" ]] || { echo "Tag differs from pinned commit; stop." >&2; exit 1; }
 git -C "$checkout" archive --format=tar "$expected" src LICENSE | gzip -n > "runtime-$version.tar.gz"
 rm -rf -- "$checkout"
done
sha256sum -c runtime-archives.sha256
