"""Block network access before test imports; any attempt fails the process."""
import atexit
import os
import socket
import sys
_attempts = []
def _deny(*args, **kwargs):
    _attempts.append("network call")
    raise RuntimeError("Network access is disabled in this offline experiment")
socket.socket.connect = _deny
socket.socket.connect_ex = _deny
socket.socket.sendto = _deny
socket.create_connection = _deny
socket.getaddrinfo = _deny
def _check():
    if _attempts:
        sys.stderr.write("Offline guard detected a network attempt\n")
        sys.stderr.flush()
        os._exit(86)
atexit.register(_check)
