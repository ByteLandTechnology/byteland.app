"""Offline probes derived from LangGraph 1.2.16's own regression tests."""
import json, operator, uuid
from collections import Counter
from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START
from langgraph.types import Command, interrupt
from langgraph.checkpoint.memory import InMemorySaver
class State(TypedDict):
    log: Annotated[list[str], operator.add]
def config(): return {'configurable': {'thread_id':str(uuid.uuid4())}}
def resumed_updates(durability):
    def ask(state):
        answers=[interrupt(str(i)) for i in range(1,4)]
        return {'log':['a:'+''.join(answers)]}
    g=StateGraph(State).add_node('a',ask).add_edge(START,'a').compile(checkpointer=InMemorySaver())
    c=config(); g.invoke({'log':[]},c,durability=durability)
    for i in range(1,4):
        result=g.invoke(Command(resume=str(i),update={'log':[f'u{i}']}),c,durability=durability)
    return {'returned_log':sorted(result['log']), 'stored_log':sorted(g.get_state(c).values['log'])}
def nested(durability):
    calls=Counter()
    def a(state):
        calls['a']+=1
        return {'log':['a:'+interrupt('A')]}
    def b(state):
        calls['b']+=1
        return {'log':['b:'+interrupt('B')]}
    child=StateGraph(State).add_node('a',a).add_node('b',b).add_edge(START,'a').add_edge(START,'b').compile()
    g=StateGraph(State).add_node('child',child).add_edge(START,'child').compile(checkpointer=InMemorySaver())
    c=config(); g.invoke({'log':[]},c,durability=durability)
    for question,answer in [('A','yes'),('B','ok')]:
        snap=g.get_state(c)
        ident=next(i.id for i in snap.interrupts if i.value==question)
        result=g.invoke(Command(resume={ident:answer}),c,durability=durability)
    return {'log':sorted(result['log']),'node_entry_counts':dict(calls)}
def restart_control():
    effects=[]
    def a(state):
        effects.append('before_interrupt')
        answer=interrupt('approve?')
        effects.append('after_interrupt')
        return {'log':[answer]}
    g=StateGraph(State).add_node('a',a).add_edge(START,'a').compile(checkpointer=InMemorySaver())
    c=config();g.invoke({'log':[]},c);g.invoke(Command(resume='yes'),c)
    return effects
print(json.dumps({'resume_updates':{d:resumed_updates(d) for d in ('sync','async','exit')},'nested_tasks':{d:nested(d) for d in ('sync','async','exit')},'restart_control':restart_control()},indent=2))
