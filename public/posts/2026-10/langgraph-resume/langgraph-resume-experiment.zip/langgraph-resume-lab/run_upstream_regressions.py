"""Run real upstream regression functions against either release's runtime.
Usage: PYTHONPATH=<release>/libs/langgraph python run_upstream_regressions.py
The tests are unmodified functions from the 1.2.16 repository.
"""
import asyncio, json, runpy, sys, traceback
from pathlib import Path
ROOT=Path(__file__).parent
sys.path.append(str(ROOT/'upstream_tests'))
from langgraph.checkpoint.memory import InMemorySaver
import langgraph.pregel._loop as loop
runtime_source=loop.__file__
state=runpy.run_path(str(ROOT/'upstream_tests/tests/test_interrupt_state.py'))
interruption=runpy.run_path(str(ROOT/'upstream_tests/tests/test_interruption.py'))
results=[]
def check(name, fn, *args):
    try:
        result=fn(*args)
        if asyncio.iscoroutine(result): asyncio.run(result)
        status='PASS'; error=None
    except Exception as exc:
        status='FAIL'; error=repr(exc)
    results.append({'test':name,'status':status,'error':error})
for durability in ('sync','async','exit'):
    for name in ('test_finished_task_output_applies_once','test_resume_with_update_applies_the_update_once','test_subgraph_finished_task_is_not_rerun'):
        check(name+'/'+durability,state[name],InMemorySaver(),durability)
for mode in ('none','head'):
    name='test_resume_at_the_latest_checkpoint_does_not_rerun_finished_task'
    check(name+'/'+mode,state[name],InMemorySaver(),mode)
name='test_nested_entrypoint_finished_task_is_not_rerun'
check(name,state[name],InMemorySaver())
name='test_invalid_resume_lets_other_answered_tasks_finish'
check(name,interruption[name],InMemorySaver())
print(json.dumps({'runtime_source':runtime_source,'results':results,'passed':sum(r['status']=='PASS' for r in results),'total':len(results)},indent=2))
