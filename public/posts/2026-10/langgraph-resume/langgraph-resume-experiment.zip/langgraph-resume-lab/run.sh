#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON=${PYTHON:-python}
PYTHON=$(command -v "$PYTHON")
mkdir -p results
LAB_HOME=$(mktemp -d)
trap 'rmdir "$LAB_HOME" 2>/dev/null || true' EXIT
for version in 1.2.15 1.2.16; do
  for script in run_upstream_regressions observe_resume; do
    prefix=regressions
    [ "$script" = observe_resume ] && prefix=observations
    env -i PATH="$PATH" HOME="$LAB_HOME" LANGSMITH_TRACING=false LANGCHAIN_TRACING_V2=false PYTHONPATH="$PWD/offline_guard:$PWD/runtimes/$version" "$PYTHON" "$script.py" > "results/$prefix-$version.json"
  done
done
env -i PATH="$PATH" HOME="$LAB_HOME" PYTHONPATH="$PWD/offline_guard" "$PYTHON" verify_results.py
