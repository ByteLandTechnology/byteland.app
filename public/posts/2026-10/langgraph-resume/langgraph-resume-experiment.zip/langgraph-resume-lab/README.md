# LangGraph 1.2.16 resume regression lab

Offline execution of real LangGraph runtime code, observed outputs, and selected upstream regression functions. No model, inference request, API key, external side effect, or paid service is used. Package installation needs network access; execution itself does not. The runner starts test processes with a clean environment, an empty temporary HOME, tracing explicitly disabled, and a Python socket/DNS guard loaded before imports. Any network attempt causes failure, even if a library catches the initial exception. This guard covers these Python-only experiments; it is not a general-purpose sandbox for arbitrary subprocesses.

## Reproduce

Tested with CPython 3.12.14 on Linux. From this folder:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r dependencies.txt
PYTHON="$PWD/.venv/bin/python" bash run.sh
```

Expected final line: `Verified: baseline 3/13; patched 13/13; observed outputs and restart control match.`

`run.sh` sets PYTHONPATH to each bundled source tree. The installed langgraph package supplies a consistent dependency environment, but each run imports the core runtime from the explicitly selected source directory. This is a source-runtime comparison, not two independently resolved stock package installations. Both runtimes share the exact dependencies in dependencies.txt. The JSON results record the actual runtime path.

## Provenance

- 1.2.15 source: https://github.com/langchain-ai/langgraph/tree/08a345637fb2bd499f69c90056a22c478a468817/libs/langgraph/langgraph
- 1.2.16 source: https://github.com/langchain-ai/langgraph/tree/41c9c22fdc83d68a2859d0c9a2b627c8615a792f/libs/langgraph/langgraph
- Test functions: test_interrupt_state.py and test_interruption.py from the latter commit, copied unmodified into upstream_tests/tests with required helper any_str.py.
- Upstream MIT license: UPSTREAM-LICENSE.
- Changes: runtime.diff; official release: https://github.com/langchain-ai/langgraph/releases/tag/1.2.16

run_upstream_regressions.py directly calls 13 selected test cases using InMemorySaver. This is not the full upstream test suite. Nine cases exercise sync, async, and exit durability with synchronous invoke; another explicitly uses ainvoke for invalid-resume isolation. `async` durability and asynchronous invocation are different concepts. Remaining cases check explicit latest checkpoint IDs and nested functional entrypoints.

observe_resume.py adapts the same minimal graph shapes to emit exact observed logs and node-entry counts. verify_results.py asserts expected old/new outputs rather than accepting either result silently.

## Limits

In-memory saver only; no PostgreSQL/SQLite persistence, process crash, distributed worker, or production throughput testing. Selected tests target known fixes and are not a broad quality score. Work before interrupt still runs again when that interrupted node resumes, in both versions. The repair does not promise exactly-once external side effects. Explicit time travel to older checkpoints is a different operation and can intentionally replay work. Use idempotency keys and suitable durable task boundaries for real-world side effects.
