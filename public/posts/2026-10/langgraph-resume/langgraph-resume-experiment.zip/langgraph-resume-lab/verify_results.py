import json
from pathlib import Path
r=Path(__file__).parent/'results'
for v,n in [('1.2.15',3),('1.2.16',13)]:
 d=json.loads((r/f'regressions-{v}.json').read_text()); assert d['passed']==n and d['total']==13
 o=json.loads((r/f'observations-{v}.json').read_text())
 assert o['restart_control']==['before_interrupt','before_interrupt','after_interrupt']
 for mode in ('sync','async','exit'):
  assert o['nested_tasks'][mode]['node_entry_counts']=={'a':3 if v=='1.2.15' else 2,'b':3}
  expected=['a:123','u1','u2','u3']
  if v=='1.2.15' and mode!='exit': expected.insert(2,'u1')
  assert o['resume_updates'][mode]['returned_log']==expected
  assert o['resume_updates'][mode]['stored_log']==expected
print('Verified: baseline 3/13; patched 13/13; observed outputs and restart control match.')
