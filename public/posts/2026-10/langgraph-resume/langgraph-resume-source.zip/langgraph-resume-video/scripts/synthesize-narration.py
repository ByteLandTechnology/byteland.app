"""Local stock-voice generation, with full telemetry opt-out before initialization."""
from pathlib import Path
import os,json,hashlib,math,time,wave
os.environ['ORT_DISABLE_TELEMETRY']='1'
import numpy as np
import onnxruntime as rt
rt.disable_telemetry_events()
from kokoro_onnx import Kokoro
P=Path(__file__).resolve().parents[1];A=P/'audio';M=P.parent/'.cache/models'
S=json.loads((A/'segments.json').read_text());sr=24000
opts=rt.SessionOptions();opts.intra_op_num_threads=2;opts.inter_op_num_threads=1
opts.execution_mode=rt.ExecutionMode.ORT_SEQUENTIAL
session=rt.InferenceSession(str(M/'kokoro-v1.0.onnx'),opts,providers=['CPUExecutionProvider'])
model=Kokoro.from_session(session,str(M/'voices-v1.0.bin'))
parts=[];cursor=4.;starts=[];scene=-1;begin=time.monotonic()
for i,s in enumerate(S):
 x,rate=model.create(s['spoken'],voice='af_heart',speed=1.04,lang='en-us')
 assert rate==sr and np.isfinite(x).all()
 if s['scene']!=scene:starts.append(round(cursor,6));scene=s['scene']
 s['start']=round(cursor,6);s['end']=round(cursor+len(x)/sr,6)
 parts.extend([x,np.zeros(round(.22*sr),dtype=np.float32)])
 cursor=s['end']+.22
 print(f'Segment {i+1}: {s["start"]:.3f}–{s["end"]:.3f}s; elapsed {time.monotonic()-begin:.1f}s',flush=True)
x=np.concatenate(parts); raw_peak=float(np.max(np.abs(x))); source_gain=min(1.,.88/raw_peak); x*=source_gain; assert np.max(np.abs(x))<1
with wave.open(str(A/'narration.wav'),'wb') as w:
 w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(np.round(x*32767).astype('<i2').tobytes())
(A/'segments.json').write_text(json.dumps(S,ensure_ascii=False,indent=2))
(A/'narration-script.txt').write_text('\n\n'.join(s['en'] for s in S)+'\n')
outro=math.ceil((4+len(x)/sr+.24)*60)/60
T={'fps':60,'intro':4,'durationInFrames':round((outro+3)*60),'audioDuration':len(x)/sr,'scenes':starts,'outro':outro,'ending':{'spinStart':outro+1.96,'morphStart':outro+2.16,'dotAt':outro+2.70,'end':outro+3}}
(P/'src/timing.json').write_text(json.dumps(T,indent=2))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e={'revision':'langgraph-resume-v1','model':'Kokoro-82M v1.0 ONNX','stock_voice':'af_heart','reference_recording':None,'model_license':'Apache-2.0 as declared in original model card','runtime_license':'MIT','original_model_source':'https://huggingface.co/hexgrad/Kokoro-82M','export_source':'https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.0','runtime':'kokoro-onnx 0.6.1; onnxruntime 1.31.0 CPUExecutionProvider','threads':{'intra':2,'inter':1},'telemetry':'ORT_DISABLE_TELEMETRY=1 set before import; disable_telemetry_events before session','speed':1.04,'post_synthesis_speed_change':False,'raw_synthesis_peak':raw_peak,'source_peak_gain':source_gain,'sample_rate':sr,'duration':len(x)/sr,'model_sha256':sha(M/'kokoro-v1.0.onnx'),'voices_sha256':sha(M/'voices-v1.0.bin'),'script_sha256':sha(A/'narration-script.txt'),'audio_sha256':sha(A/'narration.wav'),'listening_performed':False,'listening_limit':'Human listening, pronunciation and balance review still required. No actual audio listening capability used.'}
(A/'provenance.json').write_text(json.dumps(e,indent=2));print(json.dumps(T,indent=2))
