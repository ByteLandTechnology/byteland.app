from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parents[1];T=json.loads((P/'src/timing.json').read_text())
dest=P.parent/'assets/langgraph-resume-check.mp4'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(P/'out/video-silent.mp4'),'-i',str(P/'public/narration-sfx.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','320k','-af','apad','-t',str(T['durationInFrames']/60),'-movflags','+faststart',str(dest)],check=True);print(dest)
