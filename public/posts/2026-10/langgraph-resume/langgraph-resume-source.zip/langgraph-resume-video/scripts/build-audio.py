"""BERT v12 approved sound palette; exact opener and retimed v11/v12 synthesis.
No mastering gain changes: narration PCM and its four-second placement are preserved.
"""
from pathlib import Path
import wave,json,hashlib,subprocess
import numpy as np
P=Path(__file__).resolve().parents[1];Q=P.parent/'qa';Q.mkdir(exist_ok=True);SR=24000
T=json.loads((P/'src/timing.json').read_text());states=json.loads((P/'src/brand-render-data.json').read_text())['states'];refstates=json.loads((P/'reference/bert-v12-brand-render-data.json').read_text())['states']
def read(p):
 with wave.open(str(p)) as w:
  assert w.getframerate()==SR and w.getnchannels()==1 and w.getsampwidth()==2
  return np.frombuffer(w.readframes(w.getnframes()),'<i2').copy()
def write(p,x):
 with wave.open(str(p),'wb') as w:
  w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes(np.rint(x*32768).astype('<i2').tobytes())
N=round(T['durationInFrames']/60*SR);voice=read(P/'audio/narration.wav');base=read(P/'reference/base-v11.wav');fx=np.zeros(N);stem=np.zeros(N);stem[4*SR:4*SR+len(voice)]=voice/32768;fx[:4*SR]=base[:4*SR]/32768;events=[]
keys=['center','growth','angle','titleWidth','offsets','logoScale','wordOrigin','wordScale','fusion','crossFusion','zooms','turns','fold']
assert all(a.get(k)==b.get(k) for a,b in zip(states[:240],refstates[:240]) for k in keys)
events.append(dict(start=0,end=4,kind='exact approved v12 inherited opener PCM',source='reference/base-v11.wav',retimed=False))
def add(start,y,**meta):
 i=round(start*SR);assert i>=0 and i+len(y)<=N;fx[i:i+len(y)]+=y;events.append(dict(start=start,end=start+len(y)/SR,**meta))
rng=np.random.default_rng(2026101711)
for scene in T['scenes'][1:]:
 # Match first rendered frame of each new panel, not non-frame-aligned nominal timestamp.
 start=np.ceil(scene*60)/60;d=.38;n=round(d*SR);t=np.linspace(0,1,n);sec=np.arange(n)/SR;freq=np.fft.rfftfreq(n,1/SR)
 z=rng.normal(size=n);band=np.exp(-.5*((freq-1800)/1000)**2);band[freq<250]=0;band[freq>4500]=0
 y=np.fft.irfft(np.fft.rfft(z)*band,n=n);env=30*t*t*(1-t)*(1-t);y*=env;y-=y.sum()/env.sum()*env;y*=10**(-22/20)/max(abs(y));u=np.clip((sec-.35)/.15,0,1);y*=10**(-3*u*u*(3-2*u)/20)
 add(start,y,kind='v11 continuous panel morph',retimed=True,nominal_scene=scene,source='reference/build-v11.py',envelope_peak=start+d/2)
 crest=scene+.19;start=crest-.025;d=.13;n=round(d*SR);sec=np.arange(n)/SR
 y=np.sin(2*np.pi*760*sec)*np.exp(-sec/.045)+.38*np.sin(2*np.pi*1900*sec)*np.exp(-sec/.025)+.14*np.sin(2*np.pi*3100*sec)*np.exp(-sec/.015);env=np.sin(np.minimum(sec/.025,1)*np.pi/2)**2;tail=np.minimum((d-sec)/.025,1);env*=tail**2*(3-2*tail);y*=env;y-=y.sum()/env.sum()*env;y*=10**(-26/20)/max(abs(y))
 add(start,y,kind='v11 wood new-copy accent',retimed=True,envelope_peak=crest,source='reference/build-v11.py')
centers=np.array([s['center'] for s in states]);dist=np.r_[0,np.cumsum(np.linalg.norm(np.diff(centers,axis=0),axis=1))];a=round(T['outro']*60);z=round((T['outro']+3.2/2.5)*60);d=dist[a:z+1]-dist[a];notes=[]
for frac,midi in [(.10,74),(.48,78),(.88,81)]:
 f=a+int(np.searchsorted(d,d[-1]*frac));notes.append((f/60,midi,.38,'return displacement '+str(frac)))
width=np.array([s.get('titleWidth',0) for s in states]);a=round((T['outro']+.85)*60);z=round(T['ending']['spinStart']*60);vel=np.gradient(width)*60;f=a+np.argmax(vel[a:z]);notes.append((f/60,78,.33,'wordmark reveal maximum speed'));f=a+np.flatnonzero(width[a:z]>=671.99)[0];notes.append((f/60,81,.24,'wordmark fully revealed'))
spin=T['ending']['spinStart'];dot=T['ending']['dotAt'];scale=(dot-spin)/.72
notes.extend([(spin,81,.23,'spin begins'),(spin+.21*scale,78,.22,'spin ramp / contraction'),(spin+.38*scale,76,.20,'contracting leaves'),(dot,74,.25,'dot settled')])
for start,midi,d,label in notes:
 n=round(d*SR);t=np.arange(n)/SR;freq=440*2**((midi-69)/12);y=sum(g*np.sin(2*np.pi*freq*r*t)*np.exp(-t/tau) for r,g,tau in [(1,1,.105),(2,.27,.065),(3,.1,.035),(2.76,.12,.035)])
 attack=np.sin(np.minimum(t/.009,1)*np.pi/2)**2;tail=np.minimum((d-t)/.06,1);env=attack*tail*tail*(3-2*tail);y*=env;y-=y.sum()/max(env.sum(),1)*env;y*=10**(-25/20)/max(abs(y));add(start,y,kind='v12 wood-bar melody',midi=midi,action=label,source='reference/build-v12.py',retimed=True)
n=round(.54*SR);t=np.arange(n)/SR;u=t/.54;noise=np.random.default_rng(1712).normal(size=n);freq=np.fft.rfftfreq(n,1/SR);noise=np.fft.irfft(np.fft.rfft(noise)*np.exp(-.5*((freq-1200)/650)**2),n=n);noise*=30*u*u*(1-u)*(1-u);noise*=10**(-36/20)/max(abs(noise));add(T['ending']['morphStart'],noise,kind='exact v12 contraction friction synthesis, shifted',source='reference/build-v12.py',retimed=True)
mix=stem+fx;assert np.isfinite(mix).all() and max(abs(mix))<1
write(P/'public/narration-sfx.wav',mix);write(P/'audio/effects-v2.wav',fx);write(P/'audio/narration-placement-v2.wav',stem)
out=read(P/'public/narration-sfx.wav');assert np.array_equal(out[:4*SR],base[:4*SR]);assert np.array_equal(read(P/'audio/narration-placement-v2.wav')[4*SR:4*SR+len(voice)],voice)
report=dict(revision='langgraph-resume-v1',events=events,sample_rate=SR,duration=N/SR,opener_first_240_visual_states_exact=True,opener_pcm_exact=True,narration_pcm_preserved=True,narration_start=4,narration_end=4+len(voice)/SR,mastering_gain=1,old_v1_effects_removed=True,background_bed=False,listening_performed=False,listening_status='Unverified: no audio playback/listening tool available',mix_peak_dbfs=float(20*np.log10(max(abs(mix)))),clipped_samples=int(np.sum(abs(mix)>=1)),reference_mp4_sha256='4247b5a253463a63b9f82cb7db504c3a3ba6354a038580205c8b5bb2578f474a')
(Q/'audio-design-v2.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
# Preserve exact recovered PCM/source mix, then use the prior v1 delivery mastering.
import shutil,re
shutil.copyfile(P/'public/narration-sfx.wav',P/'audio/mix-premaster-v2.wav')
first=subprocess.run(['ffmpeg','-hide_banner','-threads','2','-i',str(P/'audio/mix-premaster-v2.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
stats=json.loads(re.findall(r'\{\s*"input_i".*?\}',first.stderr,re.S)[-1]);(Q/'loudness-pass1-v2.json').write_text(json.dumps(stats,indent=2))
f='loudnorm=I=-16:TP=-1.5:LRA=7:linear=false:print_format=json:'+':'.join(f'{k}={stats[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])
second=subprocess.run(['ffmpeg','-hide_banner','-threads','2','-y','-i',str(P/'audio/mix-premaster-v2.wav'),'-af',f+',volume=-0.15dB','-ar','48000','-c:a','pcm_s16le',str(P/'public/narration-sfx.wav')],capture_output=True,text=True,check=True)
stats=json.loads(re.findall(r'\{\s*"input_i".*?\}',second.stderr,re.S)[-1]);(Q/'loudness-pass2-v2.json').write_text(json.dumps(stats,indent=2));report.update(mastering_gain='two-pass dynamic loudnorm, target -16 LUFS / -1.5 dBTP / LRA7 plus -0.15 dB AAC headroom',opener_pcm_exact='before delivery mastering and AAC only',narration_pcm_preserved='source and premaster placement; final delivery mastered',premaster_file='audio/mix-premaster-v2.wav');(Q/'audio-design-v2.json').write_text(json.dumps(report,indent=2))
