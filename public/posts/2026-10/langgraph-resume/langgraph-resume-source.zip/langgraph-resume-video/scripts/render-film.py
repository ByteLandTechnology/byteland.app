"""Native EGL/librsvg/FFmpeg rendering; no browser/network; bounded CPU use."""
from pathlib import Path
import ctypes as C,json,os,subprocess,sys,time
from PIL import Image
P=Path(__file__).resolve().parents[1]
os.environ['LIBGL_ALWAYS_SOFTWARE']='true';os.environ['LP_NUM_THREADS']='2';os.environ['MESA_SHADER_CACHE_DIR']=str(P.parent/'.cache/mesa');os.environ['XDG_CACHE_HOME']=str(P.parent/'.cache')
sys.path.insert(0,str(P/'renderer'));from brand_renderer import Renderer
rsvg=C.CDLL('librsvg-2.so.2');cairo=C.CDLL('libcairo.so.2');gobj=C.CDLL('libgobject-2.0.so.0')
def bind(lib,name,restype,args):
 f=getattr(lib,name);f.restype=restype;f.argtypes=args;return f
ptr=C.c_void_p;I=C.c_int;D=C.c_double
new=bind(rsvg,'rsvg_handle_new_from_data',ptr,[C.c_char_p,C.c_size_t,ptr]);paint=bind(rsvg,'rsvg_handle_render_cairo',I,[ptr,ptr]);surface=bind(cairo,'cairo_image_surface_create',ptr,[I,I,I]);context=bind(cairo,'cairo_create',ptr,[ptr]);color=bind(cairo,'cairo_set_source_rgb',None,[ptr,D,D,D]);fill=bind(cairo,'cairo_paint',None,[ptr]);flush=bind(cairo,'cairo_surface_flush',None,[ptr]);data=bind(cairo,'cairo_image_surface_get_data',ptr,[ptr]);destroy_context=bind(cairo,'cairo_destroy',None,[ptr]);destroy_surface=bind(cairo,'cairo_surface_destroy',None,[ptr]);unref=bind(gobj,'g_object_unref',None,[ptr])
def raster(svg):
 b=svg.encode();handle=new(b,len(b),None);assert handle
 surf=surface(0,1280,720);ctx=context(surf);color(ctx,247/255,249/255,252/255);fill(ctx);assert paint(handle,ctx)
 flush(surf);im=Image.frombytes('RGBA',(1280,720),C.string_at(data(surf),1280*720*4),'raw','BGRA');destroy_context(ctx);destroy_surface(surf);unref(handle);return im
if __name__=='__main__':
 T=json.loads((P/'src/timing.json').read_text());S=json.loads((P/'src/brand-render-data.json').read_text())['states'];Q=P.parent/'qa';Q.mkdir(exist_ok=True)
 selected=json.loads(sys.argv[1]) if len(sys.argv)>1 else None
 node=subprocess.Popen(['node',str(P/'export-stream.cjs')]+([json.dumps(selected)] if selected else []),stdout=subprocess.PIPE,text=True,cwd=P)
 r=Renderer(1280,720);start=time.monotonic();print('Renderer:',r.engine,flush=True)
 enc=None
 if not selected:enc=subprocess.Popen(['ffmpeg','-v','error','-y','-threads','2','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','60','-i','-','-an','-c:v','libx264','-threads','2','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(P/'out/video-silent.mp4')],stdin=subprocess.PIPE)
 keys={0,12,40,76,110,145,170,190,214,230,240,T['durationInFrames']-1};keys.update(round((v+.9)*60) for v in T['scenes']);keys.update(round((T['outro']+v)*60) for v in [0,.5,1,1.5,1.9,2.2,2.5,2.8]);count=0
 for line in node.stdout:
  item=json.loads(line);i=item['frame'];t=i/60;im=raster(item['svg'])
  if T['intro']<=t<T['outro']:im.alpha_composite(r.render(S[i],160,160,mode='tile'),(0,0))
  else:im.alpha_composite(r.render(S[i],1280,720,mode='transparent'))
  im=im.convert('RGB')
  if enc:enc.stdin.write(im.tobytes())
  if selected or i in keys:im.save(Q/f'key-{i:04}.png')
  count+=1
  if count%180==0:print(f'Frame {i}: {time.monotonic()-start:.1f}s',flush=True)
 assert node.wait()==0
 if enc:enc.stdin.close();assert enc.wait()==0
 print(f'Rendered {count} frames in {time.monotonic()-start:.1f}s',flush=True)
 (Q/'render-method.json').write_text(json.dumps({'revision':'langgraph-resume-v1','method':'Native EGL analytical SDF + librsvg-rendered React SVG + FFmpeg x264','browser_remotion_render':False,'renderer':r.engine,'width':1280,'height':720,'fps':60,'frames_rendered':count,'mesa_threads':2,'ffmpeg_threads':2},indent=2))
