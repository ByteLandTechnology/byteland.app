from pathlib import Path
import json,shutil,textwrap,re
P=Path(__file__).resolve().parents[1];S=json.loads((P/'audio/segments.json').read_text());T=json.loads((P/'src/timing.json').read_text())
def stamp(t,comma=False):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}{"," if comma else "."}{ms%1000:03}'
def wrap(text,lang):
 if lang=='en':return '\n'.join(textwrap.wrap(text,55,break_long_words=False,break_on_hyphens=False))
 if len(text)<42:return text
 choices=[i+1 for i,c in enumerate(text) if c in '。；，、. ' and len(text)*.3<i+1<len(text)*.75]
 if not choices:return text
 i=min(choices,key=lambda i:abs(i-len(text)/2));return text[:i].rstrip()+'\n'+text[i:].lstrip()
report={}
for lang in ['en','zh-Hans','zh-Hant','ja']:
 cues=[];srt=[];previous=0
 for i,s in enumerate(S):
  assert previous<=s['start']<s['end']<=T['durationInFrames']/60
  previous=s['end'];text=wrap(s[lang],lang)
  assert '\ufffd' not in text and text.strip()
  cues.append(f'{stamp(s["start"])} --> {stamp(s["end"])}\n{text}')
  srt.append(f'{i+1}\n{stamp(s["start"],True)} --> {stamp(s["end"],True)}\n{text}')
 p=P/'captions'/f'captions.{lang}.vtt';p.write_text('WEBVTT\n\n'+'\n\n'.join(cues)+'\n')
 (P/'captions'/f'captions.{lang}.srt').write_text('\n\n'.join(srt)+'\n');shutil.copy2(p,P.parent/'assets')
 parsed=re.findall(r'(\d{2}:\d{2}:\d{2}\.\d{3}) --> (\d{2}:\d{2}:\d{2}\.\d{3})',p.read_text())
 assert len(parsed)==len(S)
 report[lang]={'cues':len(parsed),'first_start':parsed[0][0],'last_end':parsed[-1][1],'ordered_nonoverlapping':True,'within_video_duration':True}
(P.parent/'qa/caption-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
