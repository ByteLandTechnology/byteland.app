from pathlib import Path
import subprocess,wave,json,numpy as np,hashlib
P=Path(__file__).resolve().parents[1];S=P/'source';Q=P/'qa';Q.mkdir(exist_ok=True);SR=24000
run=lambda args:subprocess.run(args,check=True)
def read(f):
 with wave.open(str(f)) as w:return np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(float)/32768
base=read(S/'v10-decoded.wav');voice=read(S/'voice-clean.wav');N=len(voice);base=base[:N];mix=base.copy();fx=np.zeros(N);events=[];rng=np.random.default_rng(2026101711)
for b in [14,24,34,44,54]:
 phases=[] if b==24 else [(b-.4,1.4,-22,'continuous panel morph')] if b==14 else [(b-.4,.658,-22 if b==44 else -26,'first-stage fold'),(b+.258,.742,-26 if b==44 else -22,'second-stage place/spread')]
 for start,d,peak,label in phases:
  n=round(d*SR);t=np.linspace(0,1,n);sec=np.arange(n)/SR;freq=np.fft.rfftfreq(n,1/SR);z=rng.normal(size=n);band=np.exp(-.5*((freq-1800)/1000)**2);band[freq<250]=0;band[freq>4500]=0
  y=np.fft.irfft(np.fft.rfft(z)*band,n=n);env=30*t*t*(1-t)*(1-t);y*=env;y-=y.sum()/env.sum()*env;y*=10**(peak/20)/max(abs(y));u=np.clip((start+sec-(b+.35))/.15,0,1);y*=10**(-3*u*u*(3-2*u)/20);i=round(start*SR);fx[i:i+n]+=y
  events.append({'start':start,'end':start+d,'kind':label,'envelope_peak':start+d/2,'actual_peak_dbfs':float(20*np.log10(max(abs(y)))),'speech_duck':'smooth 3dB from boundary+.35 to+.50'})
 crest=b+(.503 if b in [14,24] else .832);start=crest-.025;d=.13;n=round(d*SR);sec=np.arange(n)/SR
 y=np.sin(2*np.pi*760*sec)*np.exp(-sec/.045)+.38*np.sin(2*np.pi*1900*sec)*np.exp(-sec/.025)+.14*np.sin(2*np.pi*3100*sec)*np.exp(-sec/.015);env=np.sin(np.minimum(sec/.025,1)*np.pi/2)**2;tail=np.minimum((d-sec)/.025,1);env*=tail**2*(3-2*tail);y*=env;y-=y.sum()/env.sum()*env;y*=10**(-26/20)/max(abs(y));i=round(start*SR);fx[i:i+n]+=y
 events.append({'start':start,'end':start+d,'kind':'wood new-copy accent, not landing','envelope_peak':crest,'actual_peak_dbfs':-26,'speech_overlap':True})
 # Replace only transition neighborhoods; 20ms crossfades outside either old/new effects.
 a=round((b-.47)*SR);z=round((b+1.20)*SR);weight=np.ones(z-a);fade=round(.02*SR);u=np.linspace(0,1,fade);r=u*u*(3-2*u);weight[:fade]=r;weight[-fade:]=r[::-1]
 target=voice[a:z]+fx[a:z];mix[a:z]=base[a:z]*(1-weight)+target*weight
assert np.isfinite(mix).all() and max(abs(mix))<.9
assert np.array_equal(mix[:4*SR],base[:4*SR])
for name,x in [('mix-v11.wav',mix),('fx-v11.wav',fx)]:
 with wave.open(str(S/name),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes(np.rint(x*32767).astype('<i2').tobytes())
report={'revision':'v11-recovered','source_versions':'v4 clean narration/mastering stem plus v10 encoded movie, recovered from Library; unavailable v9/v10 synthesis scripts are not claimed restored','events':events,'opening_unchanged_before_final_aac_encode':True,'outside_transition_windows':'v10 decoded audio retained; final AAC re-encode is lossy, not claimed bit-identical','max_pcm':float(max(abs(mix))),'clipped_samples':int(sum(abs(mix)>=1)),'listening_performed':False};(Q/'mix-v11.json').write_text(json.dumps(report,indent=2))
run(['ffmpeg','-v','error','-y','-i',str(S/'base-v10.mp4'),'-i',str(S/'mix-v11.wav'),'-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-b:a','160k','-t',str(N/SR),'-movflags','+faststart',str(P/'tokenmaxxing-bert-v11.mp4')])
