from pathlib import Path
import numpy as np,wave,json,subprocess,hashlib
P=Path(__file__).resolve().parents[1];S=P/'source';Q=P/'qa';Q.mkdir(exist_ok=True);sr=24000
with wave.open(str(S/'base-v11.wav')) as w: base=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(float)/32768
states=json.loads((S/'brand-render-data.json').read_text())['states'];fx=np.zeros(len(base));events=[]
# Three notes follow cumulative return-to-center displacement: accelerating then easing.
centers=np.array([s['center'] for s in states]); dist=np.r_[0,np.cumsum(np.linalg.norm(np.diff(centers,axis=0),axis=1))];a=round(64.46*60);z=round(65.72*60);d=dist[a:z+1]-dist[a]
notes=[]
for frac,note in [(0.10,74),(.48,78),(.88,81)]:
 f=a+int(np.searchsorted(d,d[-1]*frac));notes.append((f/60,note,.38,'return displacement '+str(frac)))
# Reveal-speed peak and fully-open wordmark resolution.
width=np.array([s.get('titleWidth',0) for s in states]);a=round(65.4*60);z=round(66.4*60);v=np.gradient(width)*60;f=a+np.argmax(v[a:z]);notes.append((f/60,78,.33,'wordmark reveal maximum speed'))
f=a+np.flatnonzero(width[a:z]>=671.99)[0];notes.append((f/60,81,.24,'wordmark fully revealed'))
# Shorter note intervals track acceleration; contraction resolves to the tonic dot.
notes += [(66.44,81,.23,'spin begins'),(66.65,78,.22,'spin ramp / contraction'),(66.82,76,.20,'contracting leaves'),(67.16,74,.25,'dot settled')]
for start,midi,d,label in notes:
 n=round(d*sr);t=np.arange(n)/sr;freq=440*2**((midi-69)/12)
 # Plucked fundamental with warm wood-bar partials. No imported recordings.
 y=sum(g*np.sin(2*np.pi*freq*r*t)*np.exp(-t/tau) for r,g,tau in [(1,1,.105),(2,.27,.065),(3,.1,.035),(2.76,.12,.035)])
 attack=np.sin(np.minimum(t/.009,1)*np.pi/2)**2;tail=np.minimum((d-t)/.06,1);env=attack*tail*tail*(3-2*tail);y*=env;y-=y.sum()/max(env.sum(),1)*env;y*=10**(-25/20)/max(abs(y));i=round(start*sr);fx[i:i+n]+=y
 events.append(dict(start=start,end=start+d,midi=midi,note_peak_dbfs=-25,action=label))
# Subtle friction follows actual contraction speed, underneath pitched notes.
a=round(66.62*sr);n=round(.54*sr);t=np.arange(n)/sr;u=t/.54;rng=np.random.default_rng(1712);noise=rng.normal(size=n);freq=np.fft.rfftfreq(n,1/sr);noise=np.fft.irfft(np.fft.rfft(noise)*np.exp(-.5*((freq-1200)/650)**2),n=n);noise*=30*u*u*(1-u)*(1-u);noise*=10**(-36/20)/max(abs(noise));fx[a:a+n]+=noise
mix=base+fx;assert max(abs(mix))<1;assert np.array_equal(mix[:int(64.46*sr)],base[:int(64.46*sr)])
for name,x in [('mix-v12.wav',mix),('ending-fx-v12.wav',fx)]:
 with wave.open(str(S/name),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(np.rint(x*32768).astype('<i2').tobytes())
(Q/'ending-sync-v12.json').write_text(json.dumps(dict(events=events,visual_inspection='Actual v11 consecutive ending frames at 5 fps plus per-frame original render states',voice_end=63.547292,first_note=notes[0][0],last_tail_end=67.41,earlier_pcm_unchanged=True,listening_performed=False,original_synthesis=True),indent=2))
subprocess.run(['ffmpeg','-v','error','-y','-i',str(S/'base-v11.mp4'),'-i',str(S/'mix-v12.wav'),'-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-b:a','160k','-movflags','+faststart',str(P/'tokenmaxxing-bert-v12.mp4')],check=True)
subprocess.run(['ffmpeg','-v','error','-y','-ss','62.5','-i',str(P/'tokenmaxxing-bert-v12.mp4'),'-c:v','libx264','-preset','fast','-crf','20','-c:a','aac','-b:a','160k',str(P/'tokenmaxxing-bert-ending-v12.mp4')],check=True)
