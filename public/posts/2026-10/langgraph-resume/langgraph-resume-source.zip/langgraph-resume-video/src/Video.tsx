import React from 'react';
import {AbsoluteFill,Audio,useCurrentFrame,staticFile} from 'remotion';
import {BrandCanvas} from './BrandCanvas';
import T from './timing.json';
export const durationInFrames=T.durationInFrames;
const C={blue:'#007aff',green:'#34c759',red:'#ff3b30',ink:'#172033',muted:'#586579',line:'#dce5ef'};
const D={blue:'#0062cc',green:'#208235',red:'#d92820'};
const clamp=(v:number)=>Math.max(0,Math.min(1,v));
const ease=(v:number)=>{const u=clamp(v);return u*u*u*(u*(u*6-15)+10)};
const Text=({x,y,children,size=26,color=C.ink,bold=false,mono=false}:{x:number;y:number;children:React.ReactNode;size?:number;color?:string;bold?:boolean;mono?:boolean})=><text x={x} y={y} fontSize={size} fill={color} fontWeight={bold?700:400} fontFamily={mono?'DejaVu Sans Mono,monospace':'DejaVu Sans,sans-serif'}>{children}</text>;
const Box=({x,y,w,h,color=C.blue,fill='white',children}:{x:number;y:number;w:number;h:number;color?:string;fill?:string;children?:React.ReactNode})=><g><rect x={x} y={y} width={w} height={h} rx={20} fill={fill} stroke={color} strokeWidth={2}/>{children}</g>;
const Arrow=({x,y,w=62,color=C.muted}:{x:number;y:number;w?:number;color?:string})=><path d={`M${x} ${y}h${w}m-10 -8l10 8-10 8`} fill="none" stroke={color} strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"/>;
const Tag=({x,y,w,children,color=D.blue}:{x:number;y:number;w:number;children:React.ReactNode;color?:string})=><g><rect x={x} y={y} width={w} height={38} rx={19} fill={color}/><Text x={x+20} y={y+26} size={20} color="white" bold>{children}</Text></g>;
const labels=['PAUSE AND RESUME','COUNT THE ACTIONS','CHECK STATE WRITES','DESIGN FOR RETRIES'];
function Chapter({index,local}:{index:number;local:number}){
 if(index===0)return <>
  <Tag x={72} y={166} w={452}>LangGraph 1.2.16 · October 16</Tag>
  <Text x={72} y={260} size={35} bold>Pause together. Resume one at a time.</Text>
  {[['A','approve A'],['B','approve B'],['C','approve C']].map((a,j)=>{
   const done=local>2+j*1.7;return <g key={a[0]}>
    <Box x={72+j*390} y={318} w={356} h={192} color={done?C.green:C.blue} fill={done?'#effaf2':'white'}>
     <Text x={100+j*390} y={369} size={25} color={D.blue} bold>BRANCH {a[0]}</Text>
     <Text x={100+j*390} y={425} size={27} mono>{done?a[1]:'interrupt()'}</Text>
     <Text x={100+j*390} y={475} size={22} color={done?D.green:C.muted}>{done?'Resumed':'Waiting for input'}</Text>
    </Box>{j<2&&<Arrow x={438+j*390} y={418} w={20}/>}</g>;
  })}
  <Text x={72} y={599} size={25} color={C.muted}>Illustration: same thread, separate resume calls.</Text>
 </>;
 if(index===1)return <>
  <Tag x={72} y={166} w={418}>13 selected upstream test cases</Tag>
  <Box x={72} y={267} w={530} h={267} color={C.red}><Text x={102} y={319} size={28} color={D.red} bold>1.2.15</Text><Text x={102} y={423} size={76} mono color={D.red}>3 / 13</Text><Text x={102} y={493} size={26} color={C.muted}>Selected cases passed</Text></Box>
  <Box x={642} y={267} w={566} h={267} color={C.green} fill="#effaf2"><Text x={672} y={319} size={28} color={D.green} bold>1.2.16</Text><Text x={672} y={423} size={76} mono color={D.green}>13 / 13</Text><Text x={672} y={493} size={26} color={C.muted}>Selected cases passed</Text></Box>
  <Text x={72} y={589} size={24} color={C.muted}>Same dependencies · InMemorySaver · No model calls</Text>
  <Text x={72} y={628} size={21} color={C.muted}>Local workflow regression checks, not an intelligence benchmark.</Text>
 </>;
 if(index===2)return <>
  <Box x={72} y={197} w={1136} h={102} color={C.green} fill="#effaf2"><Text x={104} y={260} size={32} color={D.green} bold>Matching final state does not prove matching work.</Text></Box>
  <Box x={72} y={349} w={530} h={199} color={C.blue}><Text x={104} y={401} size={28} color={D.blue} bold>State snapshot</Text><Text x={104} y={463} size={29} mono>a:yes   b:ok</Text><Text x={104} y={516} size={22} color={C.muted}>Both versions: same final log.</Text></Box>
  <Box x={642} y={349} w={566} h={199} color={C.red}><Text x={674} y={401} size={28} color={D.red} bold>Node-entry counts</Text><Text x={674} y={463} size={26} mono>A: 3 → 2   B: 3 → 3</Text><Text x={674} y={516} size={22} color={C.muted}>1.2.15 → 1.2.16 · includes pauses</Text></Box>
  <Text x={72} y={611} size={24} color={C.muted}>Also fixed: duplicate state updates during resume.</Text>
 </>;
 return <>
  <Tag x={72} y={166} w={476}>Interrupted node restarts from the top</Tag>
  <Box x={72} y={282} w={356} h={202} color={C.red}><Text x={100} y={338} size={27} color={D.red} bold>Before interrupt</Text><Text x={100} y={403} size={24}>Side effect</Text><Text x={100} y={451} size={22} color={C.muted}>Can run again</Text></Box>
  <Arrow x={442} y={389} w={54}/>
  <Box x={514} y={282} w={286} h={202} color={C.blue}><Text x={542} y={338} size={27} color={D.blue} bold>Pause</Text><Text x={542} y={403} size={25} mono>interrupt()</Text><Text x={542} y={451} size={22} color={C.muted}>Wait → resume</Text></Box>
  <Arrow x={814} y={389} w={54}/>
  <Box x={886} y={282} w={322} h={202} color={C.green}><Text x={914} y={338} size={27} color={D.green} bold>Continue</Text><Text x={914} y={403} size={24}>Use the answer</Text><Text x={914} y={451} size={22} color={C.muted}>Finish the node</Text></Box>
  <path d="M654 282V239H249V282m-8-10l8 10 8-10" fill="none" stroke={D.red} strokeWidth={3} strokeDasharray="8 7"/>
  <Text x={72} y={569} size={27} bold>Make repeated side effects safe.</Text>
  <Text x={72} y={616} size={23} color={C.muted}>This fix does not provide a general exactly-once guarantee.</Text>
 </>;
}
export function Frame({frame}:{frame:number}){
 const t=frame/60;let idx=0;for(let j=1;j<T.scenes.length;j++)if(t>=T.scenes[j])idx=j;
 const local=t-T.scenes[idx],enter=ease((t-3.62)/.55),exit=ease((t-(T.outro-.2))/.4),contentIn=idx===0?1:ease(local/.38),slide=48*(1-enter)-42*exit;
 return <svg xmlns="http://www.w3.org/2000/svg" width={1280} height={720} viewBox="0 0 1280 720" role="img" aria-label={labels[idx]}>
 <defs><linearGradient id="theme"><stop stopColor={D.blue}/><stop offset=".5" stopColor={D.green}/><stop offset="1" stopColor={D.red}/></linearGradient><linearGradient id="progress"><stop stopColor={C.blue}/><stop offset=".5" stopColor={C.green}/><stop offset="1" stopColor={C.red}/></linearGradient><clipPath id="header"><rect x={112} y={30} width={1090*enter*(1-exit)} height={58}/></clipPath><clipPath id="body"><rect x={64} y={125} width={1152*enter*(1-exit)} height={520}/></clipPath><clipPath id="progressClip"><rect x={0} y={714} width={1280*clamp(frame/(durationInFrames-1))} height={6}/></clipPath></defs>
 <g clipPath="url(#header)" transform={`translate(${slide} 0)`}><Text x={112} y={73} size={27} color="url(#theme)" bold>{labels[idx]}</Text></g>
 <g clipPath="url(#body)"><g data-shared="workflow-content-carrier" transform={`translate(${slide+24*(1-contentIn)} ${-10*exit})`} opacity={contentIn}><Chapter index={idx} local={local}/></g></g>
 <rect y={714} width={1280} height={6} fill="#e2e8f0"/><rect y={714} width={1280} height={6} fill="url(#progress)" clipPath="url(#progressClip)"/>
 </svg>;
}
export const Video=()=>{const frame=useCurrentFrame();return <AbsoluteFill style={{background:'#f7f9fc'}}><Frame frame={frame}/><BrandCanvas time={frame/60}/><Audio src={staticFile('narration-sfx.wav')}/></AbsoluteFill>};
