const path=require('path'),fs=require('fs');fs.mkdirSync(path.join(__dirname,'out'),{recursive:true});
require('esbuild').buildSync({entryPoints:[path.join(__dirname,'src/Video.tsx')],outfile:path.join(__dirname,'out/frame.cjs'),bundle:true,platform:'node',format:'cjs',external:['react','remotion'],jsx:'automatic'});
const React=require('react'),{renderToStaticMarkup}=require('react-dom/server'),{Frame,durationInFrames}=require('./out/frame.cjs');
const frames=process.argv[2]?JSON.parse(process.argv[2]):Array.from({length:durationInFrames},(_,i)=>i);
async function run(){for(const frame of frames){if(!process.stdout.write(JSON.stringify({frame,svg:renderToStaticMarkup(React.createElement(Frame,{frame}))})+'\n'))await new Promise(r=>process.stdout.once('drain',r));}}
run().catch(e=>{console.error(e);process.exitCode=1});
