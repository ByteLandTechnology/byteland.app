# ByteLand: LangGraph resume regression checks

Editable 1280 × 720, 60 fps film source. Four chapters cover pause/resume,
selected regression test results, state writes, and retry-safe external actions.
No model calls were used in the workflow experiment.

## Actual rendering method

The delivered MP4 uses native EGL analytical SDF brand rendering, React SVG
rendered through librsvg/Cairo, and FFmpeg/x264. It is **not a browser Remotion
render**. The optional Remotion composition is editable but was not used for the
final export. Remotion 4.0.534's license is included; verify its applicability for
your organization before choosing the optional Remotion route. No paid rendering
service was used.

The approved v12 SDF three-leaf mark and E3 wordmark retain their original opening
state sequence and sound palette. Chapter timing and ending events are retimed to
the new narration. Text is instructional diagram text; captions remain external.

## Rebuild

Use a local virtual environment and the pinned requirements.txt. Native system
libraries required: libEGL, Mesa software rendering, librsvg, Cairo, FFmpeg, Node.
Run npm ci to install the package-lock.json dependencies. The source archive does
not contain dependency directories, models or render caches.

Place the official Kokoro v1.0 ONNX model and voices-v1.0.bin in
../.cache/models/. URLs and SHA-256 hashes are in audio/provenance.json.

1. python scripts/synthesize-narration.py
2. node build-brand.cjs
3. npm run typecheck
4. python scripts/build-captions.py
5. python scripts/build-audio.py
6. python scripts/render-film.py
7. python scripts/mux.py

Create ../assets and ../qa first. scripts/mux.py exports the MP4 into ../assets.
No login, credentials or API access is required for the actual synthesis/render.

## Audio and captions

Narration uses the stock American-English Kokoro af_heart voice, without voice
cloning or a reference recording. The original Kokoro model is Apache-2.0;
kokoro-onnx runtime is MIT. See licenses and audio/provenance.json.
Audio synthesis telemetry is disabled before model session creation. A uniform
source gain prevents PCM clipping; delivery mastering targets -16 LUFS and
-1.5 dBTP with additional AAC headroom. Sound effects are procedural.

English, Simplified Chinese, Traditional Chinese and Japanese VTT/SRT files use
individual narration-segment timing. No captions are burned into the picture.

## Review boundaries

The test numbers apply to thirteen selected upstream regression cases, run with
matched dependencies and InMemorySaver. They are not an intelligence score or a
production checkpoint-store guarantee. Interrupted nodes restart at their entry;
side effects before interrupt() still need retry safety.

Visual keyframes, caption times, audio metrics, and decoding are checked by code.
Human listening and pronunciation/balance review remain necessary: no actual
listening test is claimed. Review the exact draft before any publication.

reference/base-v11.wav contains only the four-second inherited opening effects,
not any previous film narration. The historical build-v11.py/build-v12.py files
are sound-design references; use scripts/build-audio.py for this film.
