#!/usr/bin/env python3
"""Run the pinned deterministic demo with narrow, defense-in-depth guards.

This is an inspection aid for trusted, pinned fixture code, not an OS sandbox.
It deliberately cannot launch model runtimes, shells, servers, or benchmarks.
"""
from __future__ import annotations

import ast
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parent
UPSTREAM = ROOT / "upstream"
RUNTIME = Path(sys.base_prefix).resolve()
COUNTS = {"approved_python_subprocesses": 0, "network_attempts": 0,
          "blocked_dotenv_probes": 0, "blocked_actions": 0}


def inside(path: Path, root: Path) -> bool:
    return path == root or root in path.parents


def full(path, dir_fd=None):
    if isinstance(path, int):
        return None
    if dir_fd is not None and dir_fd != -1 and not os.path.isabs(path):
        # shutil's fd-relative removals operate only on previously opened dirs.
        return None
    return Path(os.fsdecode(path)).resolve()


def deny(message):
    COUNTS["blocked_actions"] += 1
    raise PermissionError(message)


def check_write(path, dir_fd=None):
    p = full(path, dir_fd)
    if p is not None and not inside(p, ROOT):
        deny(f"Write outside experiment refused: {p}")


def audit(event, args):
    if event.startswith("socket."):
        COUNTS["network_attempts"] += 1
        deny("Networking disabled for deterministic experiment")
    if event == "open":
        p = full(args[0])
        if p is None:
            return
        if p.name == ".env":
            COUNTS["blocked_dotenv_probes"] += 1
            raise FileNotFoundError("Dotenv is deliberately unavailable")
        if any(part in {".ssh", ".aws", ".codex", ".config"} for part in p.parts):
            deny("Credential/config path refused")
        flags = args[2] or 0
        if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
            check_write(p)
        elif not (inside(p, ROOT) or inside(p, RUNTIME) or p == Path("/dev/null")):
            deny(f"Read outside experiment/runtime refused: {p}")
    if event in {"os.mkdir", "os.remove", "os.rmdir", "os.chmod"}:
        check_write(args[0], args[-1] if event != "os.chmod" else args[2])
    if event in {"os.rename", "os.link"}:
        check_write(args[0], args[2])
        check_write(args[1], args[3])
    if event in {"os.system", "os.posix_spawn", "os.posix_spawnp", "os.exec", "os.symlink"}:
        deny(f"Unsupported operation refused: {event}")


def prepare():
    if sys.version_info[:2] != (3, 12):
        raise RuntimeError("This reproduction was pinned to Python 3.12")
    for name in ("home", "tmp", "results"):
        (ROOT / name).mkdir(exist_ok=True)
    os.chdir(ROOT)
    os.environ.clear()
    os.environ.update({
        "HOME": str(ROOT / "home"), "TMPDIR": str(ROOT / "tmp"),
        "PATH": str(Path(sys.executable).parent) + ":/usr/bin:/bin",
        "LANG": "C.UTF-8", "PYTHONNOUSERSITE": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
    })
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(UPSTREAM))
    sys.path.insert(0, str(ROOT))
    # Derive the only two permitted child programs without importing upstream.
    parsed = ast.parse((UPSTREAM / "harness2/demo.py").read_text())
    base = next(ast.literal_eval(node.value) for node in parsed.body
                if isinstance(node, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == "BASE_SCRIPT" for t in node.targets))
    approved_scripts = {base, base.replace(" if amount > 0", "")}
    original_popen = subprocess.Popen

    def narrow_popen(argv, *args, **kwargs):
        if not (isinstance(argv, (list, tuple)) and len(argv) == 3
                and Path(argv[0]).resolve() == Path(sys.executable).resolve()
                and not kwargs.get("shell")):
            deny("Only deterministic Python ledger children are permitted")
        script, fixture = Path(argv[1]).resolve(), Path(argv[2]).resolve()
        if not (inside(script, ROOT) and inside(fixture, ROOT)
                and script.name == "summarize.py" and fixture.suffix == ".csv"
                and script.read_text() in approved_scripts):
            deny("Unreviewed child program or fixture path refused")
        COUNTS["approved_python_subprocesses"] += 1
        return original_popen([argv[0], "-I", "-S", "-B", *argv[1:]], *args, **kwargs)

    subprocess.Popen = narrow_popen
    sys.addaudithook(audit)


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in {"demo", "upstream-tests", "extra-tests"}:
        raise SystemExit("Usage: safe_runner.py {demo|upstream-tests|extra-tests} [arguments]")
    command = sys.argv[1]
    argv = sys.argv[2:]
    prepare()
    code = 0
    try:
        if command == "demo":
            from harness2.cli.demo import main as official_main
            code = official_main(argv)
        else:
            path = UPSTREAM / "tests/test_workflow.py" if command == "upstream-tests" else ROOT / "test_extra.py"
            namespace = runpy.run_path(str(path), run_name="repro_tests")
            suite = unittest.TestSuite()
            for value in namespace.values():
                if isinstance(value, type) and issubclass(value, unittest.TestCase):
                    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(value))
            result = unittest.TextTestRunner(verbosity=2).run(suite)
            code = int(not result.wasSuccessful())
    finally:
        print("GUARD_COUNTS " + json.dumps(COUNTS, sort_keys=True))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
