"""ByteLand's extra deterministic checks; not upstream model benchmarks."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from harness2.cli.demo import main as demo_main
from harness2.core import recursion, schedule, tree
from harness2.core.proposer import Reply
from harness2.demo import BASE_SCRIPT, DemoAdapter, DemoProposer

ROOT = Path(__file__).resolve().parent


class ExtraTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)

    def run_script(self, csv_text, *, fixed=True):
        script = self.root / "summarize.py"
        script.write_text(BASE_SCRIPT.replace(" if amount > 0", "") if fixed else BASE_SCRIPT)
        fixture = self.root / "fixture.csv"
        fixture.write_text(csv_text)
        return subprocess.run([sys.executable, str(script), str(fixture)],
                              capture_output=True, text=True, timeout=10)

    def test_signed_decimal_edges(self):
        cases = [
            ("negative_only", "amount\n-5.00\n-2.50\n", "Total: -7.50\n"),
            ("fractional_net_negative", "amount\n0.10\n-0.20\n", "Total: -0.10\n"),
            ("cancel_to_zero", "amount\n10.25\n-10.25\n0.00\n", "Total: 0.00\n"),
            ("empty_ledger", "amount\n", "Total: 0.00\n"),
        ]
        observed = []
        for name, fixture, expected in cases:
            with self.subTest(name=name):
                result = self.run_script(fixture)
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stdout, expected)
                observed.append({"name": name, "observed": result.stdout.strip()})
        (ROOT / "results/edge-cases.json").write_text(json.dumps(observed, indent=2) + "\n")

    def test_malformed_amount_is_not_silently_accepted(self):
        result = self.run_script("amount\nnot-a-number\n")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("decimal.InvalidOperation", result.stderr)

    def test_missing_amount_column_fails(self):
        result = self.run_script("value\n1.00\n")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("KeyError: 'amount'", result.stderr)

    def test_nonpositive_recursion_budget_rejected(self):
        with self.assertRaises(SystemExit) as caught:
            demo_main(["--output", str(self.root / "should-not-exist"), "--k", "0"])
        self.assertEqual(caught.exception.code, 2)
        self.assertFalse((self.root / "should-not-exist").exists())

    def test_unsupported_mode_rejected(self):
        with self.assertRaises(SystemExit) as caught:
            demo_main(["--output", str(self.root / "should-not-exist"), "--mode", "invalid"])
        self.assertEqual(caught.exception.code, 2)
        self.assertFalse((self.root / "should-not-exist").exists())

    def test_path_escape_rejected(self):
        for name in ("../outside.py", "/absolute.py", "scripts/../../outside.py"):
            with self.subTest(name=name), self.assertRaises(ValueError):
                tree.normalize_rel(name)

    def test_invalid_edits_exhaust_retry_then_fall_back(self):
        class Broken(DemoProposer):
            def call(self, mission, context_dir, label, **kwargs):
                workspace = Path(context_dir) / "harness"
                (workspace / "scripts/summarize.py").write_text("def broken(:\n")
                return Reply(label, "deliberately invalid", True, attempts=1, workspace=workspace)

        adapter = DemoAdapter(self.root)
        fallback = tree.read_tree(adapter.substrate.surface(), adapter.base_harness())
        stage = recursion._run_stage(
            label="inv1", dim="INV", job="Deliberate invalid-edit control", fallback=fallback,
            adapter=adapter, prop=Broken(adapter.spec.channels["proposer"]),
            ctx_dir=self.root / "context", task_id="ledger-1", rollouts=[],
            harness_dir=adapter.base_harness(), library_dir=None,
        )
        self.assertTrue(stage.fell_back)
        self.assertEqual(stage.attempts, 2)
        self.assertEqual(stage.tree, fallback)
        self.assertIn("SyntaxError", stage.error)
        self.assertEqual(adapter.execution_count, 0)
        (ROOT / "results/invalid-edit-fallback.json").write_text(json.dumps({
            "attempts": stage.attempts, "fell_back": stage.fell_back,
            "executions": adapter.execution_count, "error": stage.error,
        }, indent=2) + "\n")

    def test_positive_only_control_exposes_scripted_reflection_limit(self):
        output = ROOT / "runs/positive-control"
        adapter = DemoAdapter(output)
        (adapter.task_files("ledger-1") / "ledger.csv").write_text("amount\n100.25\n5.00\n")
        proposer = DemoProposer(adapter.spec.channels["proposer"])
        result = schedule.run_domain(
            "accounting", ["ledger-1"], 1, adapter=adapter, prop=proposer,
            runs_root=adapter.spec.runs_root, library_root=output / "library/k1",
        )
        self.assertEqual((result["done"], result["failed"]), (1, 0))
        summary = json.loads((adapter.spec.runs_root / "demo-oc-agg1/ledger-1/summary.json").read_text())
        base = (Path(summary["base"][0]["run_dir"]) / "answer.txt").read_text()
        observations = []
        for mode, selection in summary["selections"].items():
            final = (Path(selection["chosen_run_dir"]) / "answer.txt").read_text()
            self.assertEqual(base, "Total: 105.25\n")
            self.assertEqual(final, base)
            self.assertIn("verdict: helped", selection["experience"]["edits"])
            observations.append({
                "mode": mode, "base": base.strip(), "adopted": final.strip(),
                "actual_output_changed": final != base,
                "scripted_reflection": selection["experience"],
            })
        (ROOT / "results/positive-control.json").write_text(json.dumps({
            "explanation": "The toy reflector checks script text inequality, not measured answer improvement.",
            "not_a_model_benchmark": True, "observations": observations,
        }, indent=2) + "\n")
