# Source provenance

The source was acquired from the official public Google Research repository:
https://github.com/google-research/harness2

`git ls-remote ... HEAD` returned `1cfe254e8d25b15f37048c3730134686abe60335`.
A fresh shallow clone was checked out detached at that commit. The commit subject
was `Fix arXiv link`; its committer timestamp was `2026-10-13T21:22:49-05:00`.
`git status --porcelain` was empty after all experiments.

`SOURCE_SHA256.json` covers every included upstream file, copied byte-for-byte
from that checkout. All first-party Python modules, the official workflow tests,
pyproject.toml, README and LICENSE are included. No third-party code or benchmark
assets are included. Package version is 0.1.0; method version in config is 2.

Inspection before execution covered README, pyproject.toml, demo CLI and adapter,
config import behavior, subprocess calls, workflow tests, recursion, scheduling,
context/evidence construction, tree validation and the OpenCode surface adapter.
The root had no AGENTS.md. A nested third-party Codex harness instruction file
was outside the used code and was neither executed nor changed.

The local wrapper does not modify upstream source. It clears the environment,
blocks dotenv/network reads, constrains writes and allowlists the inspected
ledger child programs. The subprocess invocation adds Python isolation flags.
See README for the limits of these defense-in-depth guards.

Source license: Apache License, Version 2.0. Copyright notices are retained.
