# Harness²: a small, credential-free local experiment

ByteLand, 18 October 2026. This package reproduces the official deterministic
demo at commit `1cfe254e8d25b15f37048c3730134686abe60335`, package version 0.1.0.
It is a workflow experiment, **not a model or benchmark evaluation**.

## Run from a fresh extraction

Use Linux and Python 3.12. The measured interpreter was CPython 3.12.14. No pip,
uv, optional rendering package, model service, or network access is needed once
the ZIP is extracted. Do not put credentials or private data in this directory.
Read `safe_runner.py` and `upstream/harness2/demo.py` before running.

```sh
python3 -I -S -B verify_snapshot.py
python3 -I -S -B safe_runner.py demo --output runs/demo --k 2
python3 -I -S -B safe_runner.py demo --output runs/demo --k 2
python3 -I -S -B safe_runner.py upstream-tests
python3 -I -S -B safe_runner.py extra-tests
```

The first command verifies the included upstream files against `SOURCE_SHA256.json`.
The two demo commands call the **unmodified official CLI main function** with
the same arguments as `harness2-demo --output runs/demo --k 2`. We ran from source;
we did not install the package. The upstream README describes the separate uv
installation route, including optional rendering dependencies that this demo
does not require. Full benchmark installation is outside this package's scope.

Fresh run: 2 tasks completed, 0 failed, 28 Python executions, 32 deterministic
editor/selector/reflection calls. Same-path repeat: both tasks skipped, 0 new
executions and 0 new editor calls. See the newly generated `runs/demo/demo.json`.
Do not confuse a resumed run's zero counts with the original run's counts.

## What happened

| Fixture | Base | Adopted, both modes |
| --- | ---: | ---: |
| 100.25, -20.10, 5.00 | 105.25 | 85.15 |
| 35.50, -10.25, -5.00 | 35.50 | 20.25 |

The proposed edit removes `if amount > 0` from `scripts/summarize.py`.
Probes execute real Python; compositions receive the base outputs, candidate
diffs, rollouts, and decision notes. The resulting harness and a reflection are
stored in the library. Ledger 2's edit context contains Ledger 1's adopted entry.
This verifies context propagation, not that the scripted editor learns from it.

Each task/mode records 8 rollouts and 6 improvement stages at k=2. The modes share
2 base executions per task, so the combined total is 28 executions, not 32.
The 32 scripted calls are 24 improvement stages, 4 selections, and 4 reflections.
Parallel mode's two compositions are identical. The second sequential round
makes no further script change after the first correction.

## Checks and a useful limitation

All 5 upstream regression test methods passed. They cover resume and corrupted
adopted artifacts, evidence completeness and excluded reference answers, invalid
edits retried with feedback, empty/failed reflections omitted from the library,
and failed selection never passed to a judge. Any dollar values in those tests
are **synthetic mocked accounting values**, not charges or measured API cost.

All 8 additional test methods passed: signed-decimal edge cases, malformed
amount rejection, missing-column rejection, k=0 rejection, unsupported mode
rejection, path-escape rejection, invalid-edit retry exhaustion/fallback, and a
positive-only control. Subcases are not counted as extra test methods.

In the positive-only control, both base and adopted totals are 105.25. The toy
reflector nevertheless records `verdict: helped`: it compares script text and
emits a preset lesson. This is an observed limitation of the deterministic demo,
not a test of the paper's learned reflection or evidence against its model-backed
results. It illustrates why a saved lesson is not itself proof of improvement.

## Boundaries of the result

- The edit and reflection are hard-coded. The selector independently computes
  the expected sum from the ledger. No model discovers or selects the fix.
- This does not reproduce ground-truth-free model-backed refinement, benchmark
  scores, inference costs, task generalization, or production-agent isolation.
- The runner clears inherited environment variables, uses a local empty HOME
  and TMPDIR, refuses .env reads, denies Python socket operations, restricts file
  operations, and permits child processes only for the two inspected ledger
  scripts with local CSV files. It adds `-I -S -B` to Python children.
- The guards are defense-in-depth for trusted, reviewed code. They are **not an
  OS sandbox or a general-purpose security boundary**. Only the reviewed child
  source is permitted; no model-generated child program runs.
- No OpenCode CLI, Codex executor, bridge/backend server, benchmark runner,
  credential store, or paid model service was started. Python guard counters
  recorded zero network attempts. Repository acquisition used GitHub network
  access before execution.
- The repository normally probes .env at import. This runner makes that file
  deliberately unavailable before any content is read.

## Package map

- `upstream/`: selected unmodified official source, README, tests and metadata
- `safe_runner.py`, `test_extra.py`: ByteLand experiment wrapper and extra tests
- `fixtures/`: two original ledgers and the positive-only control
- `harness/`: baseline and adopted scripts
- `results/`: compact observed results and selected official evidence artifacts
- `PINS.json`, `SOURCE_PROVENANCE.md`, `SOURCE_SHA256.json`: source/environment pins
- `LICENSE`: upstream Apache-2.0 license; upstream files retain copyright notices

This is a selective source snapshot, not a complete benchmark installation.
The archive excludes .git, .env, credentials, runtime home directories, caches,
temporary files, raw command logs, benchmark datasets and bundled third-party
code. Selected official artifact JSONs replace the original absolute experiment
prefix with `<EXPERIMENT_ROOT>` for portability; they are evidence snapshots,
not a resumable runtime directory. Fresh runs create their own absolute paths.

## Source

Repository: https://github.com/google-research/harness2

Pinned revision:
https://github.com/google-research/harness2/commit/1cfe254e8d25b15f37048c3730134686abe60335

This is not an officially supported Google product. See upstream license and
disclaimer. The wrapper and extra tests in this package are also provided under
Apache-2.0; upstream source remains unchanged.
