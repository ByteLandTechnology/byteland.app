"""Verify the selective upstream snapshot without importing or running it."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "SOURCE_SHA256.json").read_text())
for name, expected in manifest.items():
    path = root / name
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit(f"Source mismatch: {name}")
print(f"Verified {len(manifest)} pinned upstream source files.")
